"use strict";(()=>{var R={$schema:"https://acode.app/schema/plugin/v0.1.0.json",id:"acode.fs.util",name:"FS \u2014 Folder Workspace",description:"Inspect, understand, and manage a folder from inside Acode: sizes, dates, types, quick previews, folder summaries, batch actions, and cleanup insights \u2014 with a full-screen layout on phones and a resizable docked panel on larger screens.",main:"main.js",version:"1.0.0",readme:"readme.md",changelogs:"changelog.md",repository:"https://github.com/picklem0b/FS.git",icon:"icon.png",files:[],minVersionCode:290,license:"MIT",keywords:["folder","file manager","file size","workspace","cleanup","batch rename","duplicates","storage","preview"],price:59,permissions:[],author:{name:"LethaboK",email:"lethabokhedama@gmail.com",github:"https://github.com/picklem0b"}};function I(){return typeof window<"u"&&window.acode?window.acode:null}function be(){return!!I()}function x(n){let e=I();if(!e||typeof e.require!="function")return null;try{return e.require(n)||null}catch{return null}}function le(){return x("fs")||x("fsoperation")}async function je(n,e,t){let s=n||[],i=Math.max(1,Math.min(Number(e)||1,s.length||1)),r=new Array(s.length),o=0;async function c(){for(;o<s.length;){let l=o++;r[l]=await t(s[l],l)}}return await Promise.all(Array.from({length:i},c)),r}function ve(n="auto"){var c,l;let e=typeof window<"u"?window.innerWidth:1024,t=typeof window<"u"?window.innerHeight:768,s=x("settings"),i=!!((c=s==null?void 0:s.value)!=null&&c.desktopMode),r=typeof window<"u"&&(!!((l=window.matchMedia)!=null&&l.call(window,"(pointer: coarse)").matches)||"ontouchstart"in window);return{mode:n==="mobile"||n==="desktop"?n:e>=820?"desktop":"mobile",width:e,height:t,desktopMode:i,touch:r}}function ke(n){let e=x("windowresize"),t=()=>n();return e&&typeof e.on=="function"&&e.on("resize",t),window.addEventListener("resize",t),window.addEventListener("orientationchange",t),()=>{e&&typeof e.off=="function"&&e.off("resize",t),window.removeEventListener("resize",t),window.removeEventListener("orientationchange",t)}}function f(n){let e=I();try{if(typeof window<"u"&&typeof window.toast=="function"){window.toast(n);return}if(e&&typeof e.pushNotification=="function"){e.pushNotification("FS",n);return}}catch{}console.log(`[FS] ${n}`)}async function j(n,e=""){let t=x("confirm");if(!t)return!1;try{return!!await t(n,e)}catch{return!1}}async function z(n,e="",t="text"){let s=x("prompt");if(!s)return null;try{let i=await s(n,e,t,{required:!0,placeholder:e});return i==null?null:String(i)}catch{return null}}async function A(n,e,t){let s=x("select");if(!s)return null;try{let i=await s(n,e,{default:t});return i==null?null:String(i)}catch{return null}}async function Se(){let n=[],e=new Set,t=(i,r)=>{!i||e.has(i)||(e.add(i),n.push({url:i,title:r||i.split("/").filter(Boolean).pop()||i}))},s=typeof window<"u"?window.addedFolder:null;if(Array.isArray(s))for(let i of s)t(i==null?void 0:i.url,i==null?void 0:i.title);if(!n.length){let i=x("fileindex");if(i&&typeof i.query=="function")try{let r=await i.query({includeDirectories:!0,limit:1e3});for(let o of(r==null?void 0:r.entries)||[])o.isDirectory&&o.path===o.name&&t(o.rootUrl||o.url,o.name)}catch{}}return n}async function _(){let n=x("filebrowser");if(!n)return null;try{let e=await n("folder","Choose a folder to inspect",!0);return e!=null&&e.url?{url:e.url,title:e.name||e.url}:null}catch{return null}}async function ce(){let n=await _();return n?n.url:null}function ze(n){if(!n)return!1;let e=x("system")||(typeof globalThis<"u"?globalThis.system:null);try{if(e&&typeof e.openInBrowser=="function")return e.openInBrowser(n),!0;if(e&&typeof e.inAppBrowser=="function")return e.inAppBrowser(n,"Folder report",!0),!0}catch(t){console.warn("[FS] Could not open the report in a browser",t)}return!1}function he(){try{if(typeof DATA_STORAGE=="string"&&DATA_STORAGE)return DATA_STORAGE;if(typeof CACHE_STORAGE=="string"&&CACHE_STORAGE)return CACHE_STORAGE}catch{}return null}var He={png:"image/png",jpg:"image/jpeg",jpeg:"image/jpeg",gif:"image/gif",webp:"image/webp",bmp:"image/bmp",ico:"image/x-icon",avif:"image/avif",svg:"image/svg+xml"};function ae(n){let e=String(n||"").lastIndexOf(".");return e<0?null:He[String(n).slice(e+1).toLowerCase()]||null}var U=class{constructor(){let e=le();if(!e)throw new Error("Acode file system API is unavailable");this.factory=e}handle(e){let t=this.factory(e);if(!t||typeof t.lsDir!="function")throw new Error(`No file system handler for ${e}`);return t}async list(e){let s=await this.handle(e).lsDir()||[],i=e.endsWith("/")?e.slice(0,-1):e;return s.map(r=>this.normalize(r,i))}async listWithStats(e,t={}){let{concurrency:s=8,onProgress:i}=t,r=await this.list(e),o=0;return await je(r,s,async l=>{if(l.isDirectory)return l;try{let h=await this.stat(l.url);l.size=h.size,l.modified=h.modified||l.modified,l.mime=l.mime||h.mime||null}catch{}return o++,i==null||i(o,r.length),l})}async stat(e){let s=await this.handle(e).stat(),i=(s==null?void 0:s.name)||e.split("/").filter(Boolean).pop()||e;return{name:i,isFile:!!(s!=null&&s.isFile),isDirectory:!!(s!=null&&s.isDirectory),size:Number(s==null?void 0:s.size)||0,modified:Number(s==null?void 0:s.modifiedDate)||0,canRead:(s==null?void 0:s.canRead)!==!1,canWrite:(s==null?void 0:s.canWrite)!==!1,mime:ae(i)}}async exists(e){try{return!!await this.handle(e).exists()}catch{return!1}}async readText(e){return await this.handle(e).readFile("utf-8")}async readBytes(e){return await this.handle(e).readFile()}async displayUrl(e){let t=I();try{if(t&&typeof t.toInternalUrl=="function")return await t.toInternalUrl(e)}catch{}return e||null}async rename(e,t){return await this.handle(e).renameTo(t)}async move(e,t){return await this.handle(e).moveTo(t)}async copy(e,t){return await this.handle(e).copyTo(t)}async remove(e){await this.handle(e).delete()}async createFile(e,t,s=""){return await this.handle(e).createFile(t,s)}async createDirectory(e,t){return await this.handle(e).createDirectory(t)}openInEditor(e){let t=I();if(!t)return!1;try{let s=x("editorfile");if(s){let i=new s(e.name,{uri:e.url});return i&&typeof i.makeActive=="function"&&i.makeActive(),!0}if(typeof t.newEditorFile=="function")return t.newEditorFile(e.name,{uri:e.url}),!0}catch(s){console.warn("[FS] Unable to open file in editor",s)}return!1}normalize(e,t){let s=(e==null?void 0:e.name)||"";return{name:s,url:(e==null?void 0:e.url)||"",parent:t,isFile:!!(e!=null&&e.isFile),isDirectory:!!(e!=null&&e.isDirectory),isLink:!!(e!=null&&e.isLink),size:0,modified:0,mime:ae(s),kind:e!=null&&e.isDirectory?"folder":"file",raw:e}}};var de=[{key:"display_showSize",text:"Show file size",type:"boolean",defaultValue:!0,group:"Display",info:"Display the size column for every file."},{key:"display_showModified",text:"Show modified date",type:"boolean",defaultValue:!0,group:"Display",info:"Display when each file was last changed."},{key:"display_showKind",text:"Show file type",type:"boolean",defaultValue:!0,group:"Display",info:"Display whether an entry is text, image, media, or binary."},{key:"display_showIcons",text:"Show type icons",type:"boolean",defaultValue:!0,group:"Display"},{key:"display_relativeDate",text:"Use relative dates",type:"boolean",defaultValue:!0,group:"Display",info:'Show "3 h ago" instead of a full timestamp.'},{key:"display_showHidden",text:"Show hidden files",type:"boolean",defaultValue:!1,group:"Display",info:"Include dotfiles in the listing."},{key:"display_compactRows",text:"Compact rows",type:"boolean",defaultValue:!1,group:"Display",info:"Fit more entries on screen by trimming row height."},{key:"sort_field",text:"Sort by",type:"string",defaultValue:"name",group:"Sorting",options:[["name","Name"],["size","Size"],["date","Date modified"],["type","Type"]]},{key:"sort_direction",text:"Sort direction",type:"string",defaultValue:"asc",group:"Sorting",options:[["asc","Ascending"],["desc","Descending"]]},{key:"sort_foldersFirst",text:"Folders first",type:"boolean",defaultValue:!0,group:"Sorting",info:"Keep folders above files regardless of direction."},{key:"preview_textEnabled",text:"Preview text files",type:"boolean",defaultValue:!0,group:"Preview"},{key:"preview_imageEnabled",text:"Preview images",type:"boolean",defaultValue:!0,group:"Preview"},{key:"preview_maxKb",text:"Text preview limit (KB)",type:"number",defaultValue:256,group:"Preview",prompt:"Maximum size to read for a text preview, in kilobytes",promptType:"number",info:"Files above this size are not read into memory."},{key:"folder_recursive",text:"Scan subfolders",type:"boolean",defaultValue:!1,group:"Scanning",info:"Include nested files when a folder is scanned."},{key:"folder_maxDepth",text:"Maximum depth",type:"number",defaultValue:3,group:"Scanning",prompt:"Deepest level to walk when scanning subfolders",promptType:"number"},{key:"folder_maxFiles",text:"Maximum entries",type:"number",defaultValue:5e3,group:"Scanning",prompt:"Stop after this many entries",promptType:"number",info:"Prevents enormous folders from locking the listing."},{key:"folder_ignore",text:"Ignore patterns",type:"string",defaultValue:"",group:"Scanning",prompt:"Comma separated globs, e.g. *.log, build/**, .git/**",promptType:"text",info:"Globs only (*, ?, **). Matched names are hidden."},{key:"tools_batchEnabled",text:"Batch actions",type:"boolean",defaultValue:!0,group:"Tools",info:"Rename, move, copy, and delete several files at once."},{key:"tools_cleanupEnabled",text:"Cleanup insights",type:"boolean",defaultValue:!0,group:"Tools",info:"Surface temporary files, backups, duplicates, and large files."},{key:"behavior_confirmDestructive",text:"Confirm destructive actions",type:"boolean",defaultValue:!0,group:"Tools",info:"Ask before deleting or renaming."},{key:"advanced_largeSizeMb",text:"Large file threshold (MB)",type:"number",defaultValue:10,group:"Tools",prompt:"Files above this size are flagged as large",promptType:"number"},{key:"advanced_recentDays",text:"Recent file window (days)",type:"number",defaultValue:30,group:"Tools",prompt:"Files changed within this many days count as recent",promptType:"number"},{key:"report_format",text:"Report format",type:"string",defaultValue:"text",group:"Reports",options:[["text","Plain text"],["markdown","Markdown"],["csv","CSV"]],info:"CSV exports the file listing only, which is what spreadsheets want."},{key:"report_includePaths",text:"Include full paths",type:"boolean",defaultValue:!1,group:"Reports",info:"Add the full url of every entry to the report."},{key:"report_includeListing",text:"Include the file listing",type:"boolean",defaultValue:!0,group:"Reports",info:"Turn off for a summary-only report."},{key:"layout_mode",text:"Panel layout",type:"string",defaultValue:"auto",group:"Layout",options:[["auto","Automatic"],["mobile","Full screen"],["desktop","Docked side panel"]],info:"Automatic uses full screen on phones and a resizable docked panel on wider screens."},{key:"layout_side",text:"Dock side",type:"string",defaultValue:"right",group:"Layout",options:[["right","Right"],["left","Left"]]},{key:"folder_rememberLast",text:"Remember last folder",type:"boolean",defaultValue:!0,group:"Layout",info:"Reopen the previous folder when the panel starts."}],S={lastFolder:"internal_lastFolder",lastFolderTitle:"internal_lastFolderTitle",panelWidth:"internal_panelWidth",expanded:"internal_expanded",recentFolders:"internal_recentFolders"},We="file",pe="acode.fs.util:settings",W=class{constructor(e={}){this.pluginId=e.pluginId||"acode.fs.util",this.storage=e.storage!==void 0?e.storage:Ge(),this.values=new Map,this.listeners=new Set,this.load()}load(){for(let t of de)this.values.set(t.key,t.defaultValue);let e=this.read();for(let[t,s]of Object.entries(e||{}))this.values.set(t,s)}read(){if(!this.storage)return{};try{let e=this.storage.getItem(`${pe}:${this.pluginId}`);return e?JSON.parse(e):{}}catch{return{}}}persist(){if(this.storage)try{this.storage.setItem(`${pe}:${this.pluginId}`,JSON.stringify(Object.fromEntries(this.values)))}catch{}}get(e,t=void 0){return this.values.has(e)?this.values.get(e):t}set(e,t,s={}){let i=this.coerce(e,t);if(this.values.get(e)!==i&&(this.values.set(e,i),this.persist(),!s.silent))for(let r of this.listeners)r(e,i)}coerce(e,t){let s=de.find(i=>i.key===e);if(!s)return t;if(s.type==="boolean")return!!t;if(s.type==="number"){let i=Number(t);return Number.isFinite(i)?i:s.defaultValue}return t==null?s.defaultValue:String(t)}all(){return Object.fromEntries(this.values)}subscribe(e){return this.listeners.add(e),()=>this.listeners.delete(e)}applyExternal(e,t){this.set(e,t)}ignorePatterns(){return String(this.get("folder_ignore","")).split(",").map(e=>e.trim()).filter(Boolean)}toHostSettings(){return de.map(e=>{let t={key:e.key,text:e.text,icon:We,info:e.info||"",value:this.get(e.key,e.defaultValue)};return e.type==="boolean"?t.checkbox=!0:e.options?(t.select=e.options,t.valueText=s=>{var r;let i=(r=e.options)==null?void 0:r.find(([o])=>o===s);return i?i[1]:String(s??"")}):e.prompt&&(t.prompt=e.prompt,t.promptType=e.promptType||"text"),t})}};function Ge(){try{let{localStorage:n}=window,e=`${pe}:probe`;return n.setItem(e,"1"),n.removeItem(e),n}catch{return null}}var Ce=["B","KB","MB","GB","TB","PB"];function g(n,e={}){let t=Number(n);if(!Number.isFinite(t)||t<0)return"\u2014";if(t===0)return"0 B";let s=Math.min(Math.floor(Math.log(t)/Math.log(1024)),Ce.length-1),i=t/1024**s,r=s===0?0:e.precise?2:1;return`${i.toFixed(r)} ${Ce[s]}`}function E(n){let e=Number(n);return!Number.isFinite(e)||e<=0?"\u2014":new Date(e).toLocaleString(void 0,{year:"numeric",month:"short",day:"numeric",hour:"2-digit",minute:"2-digit"})}function fe(n,e=Date.now()){let t=Number(n);if(!Number.isFinite(t)||t<=0)return"\u2014";let s=Math.round((e-t)/1e3),i=[{limit:60,divisor:1,unit:"s"},{limit:3600,divisor:60,unit:"min"},{limit:86400,divisor:3600,unit:"h"},{limit:2592e3,divisor:86400,unit:"d"},{limit:31536e3,divisor:2592e3,unit:"mo"}];if(s<0)return"in the future";if(s<45)return"just now";for(let{limit:r,divisor:o,unit:c}of i)if(s<r)return`${Math.floor(s/o)} ${c} ago`;return`${Math.floor(s/31536e3)} y ago`}function v(n){let e=Number(n);return Number.isFinite(e)?e.toLocaleString():"0"}var qe=new Set(["txt","md","markdown","json","json5","js","mjs","cjs","jsx","ts","tsx","html","htm","css","scss","sass","less","xml","svg","yaml","yml","toml","ini","cfg","conf","env","properties","log","sh","bash","zsh","fish","py","rb","php","java","kt","kts","c","h","cpp","hpp","cc","cs","go","rs","swift","lua","pl","r","m","mm","dart","sql","graphql","vue","svelte","gitignore","editorconfig","dockerignore","lock"]),Ke=new Set(["png","jpg","jpeg","webp","gif","bmp","ico","avif","heic","heif","tiff","tif"]),Ye=new Set(["mp3","wav","ogg","oga","opus","flac","aac","m4a","wma","aiff","mp4","webm","mkv","mov","avi","m4v","3gp"]);function G(n,e,t=!1){if(t)return"folder";let s=String(n||""),i=s.lastIndexOf("."),r=i>0?s.slice(i+1).toLowerCase():"";if(qe.has(r))return"text";if(Ke.has(r))return"image";if(Ye.has(r))return"media";if(e){if(e.startsWith("text/"))return"text";if(e.startsWith("image/"))return"image";if(e.startsWith("audio/")||e.startsWith("video/"))return"media";if(e==="application/json"||e==="application/xml")return"text";if(e.startsWith("application/"))return"binary"}return r?"other":"unknown"}function C(n){return{text:"Text",image:"Image",media:"Media",folder:"Folder",binary:"Binary",other:"Other",unknown:"Unknown"}[n]||"Other"}var Xe=[],q=class{constructor(e,t={}){if(!e||typeof e.list!="function")throw new TypeError("FolderAccess requires a source with a list() method");this.source=e,this.caching=t.cache!==!1,this.cache=new Map,this.inflight=new Map}async scan(e,t={}){if(!e)return Xe;let{withStats:s=!0,force:i=!1,onProgress:r}=t,o=`${s?"meta":"plain"}:${e}`;if(this.caching&&!i&&this.cache.has(o))return this.cache.get(o);if(this.inflight.has(o))return this.inflight.get(o);let c=(async()=>{let h=(await this.source.list(e,{withStats:s,onProgress:r})||[]).map(p=>this.classify(p));return this.caching&&this.cache.set(o,h),h})();this.inflight.set(o,c);try{return await c}finally{this.inflight.delete(o)}}async stat(e){if(!this.source.stat)throw new Error("Source does not support stat()");return await this.source.stat(e)}invalidate(e){if(!e){this.cache.clear();return}for(let t of[...this.cache.keys()])t.endsWith(e)&&this.cache.delete(t)}classify(e){return e.kind=G(e.name,e.mime,e.isDirectory),e}};var Qe=[".DS_Store","Thumbs.db","desktop.ini",".directory","about-files.json"],Je=/[.*+?^${}()|[\]\\]/g;function Ze(n){let e=String(n).trim(),t="";for(let s=0;s<e.length;s++){let i=e[s];if(i==="*"){e[s+1]==="*"?(t+=".*",s++):t+="[^/]*";continue}if(i==="?"){t+="[^/]";continue}t+=i.replace(Je,"\\$&")}return new RegExp(`^${t}$`,"i")}function Fe(n=[]){let e=[...Qe,...n||[]].map(s=>String(s??"").trim()).filter(Boolean),t=e.map(Ze);return{matches(s){return s?t.some(i=>i.test(s)):!1},patterns:t,globs:e}}function K(n){let e=new Map;for(let t of n||[]){let s=String((t==null?void 0:t.name)||"").replace(/[/\\]+$/,"");if(!s)continue;let i=s.toLowerCase();e.has(i)||e.set(i,[]),e.get(i).push(t)}return[...e.values()].filter(t=>t.length>1)}var et=/(^\.?#.*#$|~$|\.(tmp|temp|swp|swo|part|crdownload|download)$)/i,tt=/\.(bak|backup|bkp|old|orig|save)$/i;function Y(n){return n?et.test(String(n)):!1}function X(n){return n?tt.test(String(n)):!1}function Q(n,e="file"){return e==="folder"||!n?!1:Y(n)||X(n)}var J=class{constructor(e,t={}){this.access=e,this.setIgnoreList(t.ignoreList||[]),this.maxFiles=Math.max(1,Number(t.maxFiles)||5e3),this.maxDepth=Math.max(0,Number(t.maxDepth)||5)}setIgnoreList(e){this.matcher=Fe(e||[])}setMaxFiles(e){this.maxFiles=Math.max(1,Math.floor(Number(e)||1))}setMaxDepth(e){this.maxDepth=Math.max(0,Math.floor(Number(e)||0))}async getFiles(e,t={}){let{recursive:s=!1,hideIgnored:i=!0,includeFolders:r=!0,includeFiles:o=!0,maxDepth:c=this.maxDepth,limit:l=this.maxFiles,onProgress:h}=t;if(!e)return[];let p=[],d=[{url:e,depth:0}],u=0;for(;d.length&&p.length<l;){let{url:b,depth:$}=d.shift(),T;try{T=await this.access.scan(b,{onProgress:h})}catch(m){console.warn(`[FolderScanner] Cannot read ${b}`,m);continue}u+=T.length;for(let m of T){if(p.length>=l)break;i&&this.matcher.matches(m.name)||m.isDirectory&&!r||m.isFile&&!o||(p.push(m),s&&m.isDirectory&&$<c&&d.push({url:m.url,depth:$+1}))}}return p.length>=l&&d.length&&console.warn(`[FolderScanner] Result cap of ${l} reached after ${u} entries`),p}async getFilesOnly(e,t={}){return this.getFiles(e,{...t,includeFolders:!1})}async getFoldersOnly(e,t={}){return this.getFiles(e,{...t,includeFiles:!1})}async getCleanupCandidates(e,t={}){return(await this.getFilesOnly(e,t)).filter(i=>Q(i.name,"file"))}async getDuplicates(e,t={}){let s=await this.getFilesOnly(e,t);return K(s)}async refresh(e,t={}){return this.access.invalidate(e),this.getFiles(e,t)}};var Z=class{constructor(e){this.source=e}canRead(e){return!e||e.isDirectory?!1:!!(e.url&&this.source)}getSize(e){let t=Number(e==null?void 0:e.size);return Number.isFinite(t)&&t>0?t:0}async readText(e){if(!this.canRead(e))throw new Error("Entry cannot be read");if(typeof this.source.readText!="function")throw new Error("Source does not support text reads");return await this.source.readText(e.url)}async readBytes(e){if(!this.canRead(e))throw new Error("Entry cannot be read");if(typeof this.source.readBytes!="function")throw new Error("Source does not support byte reads");return await this.source.readBytes(e.url)}async displayUrl(e){if(!(e!=null&&e.url))return null;if(typeof this.source.displayUrl!="function")return e.url;try{return await this.source.displayUrl(e.url)}catch{return e.url}}};var ee=class{constructor(e){this.reader=e,this.cache=new Map}async readText(e,t={}){let s=Number(t.maxSize)||262144;if(!this.reader.canRead(e))return{ok:!1,reason:"unreadable",message:"This entry cannot be read"};let i=this.reader.getSize(e);if(i>s)return{ok:!1,reason:"too_large",bytes:i,message:`File is larger than the ${Math.round(s/1024)} KB preview limit`};try{let r=await this.reader.readText(e),o=i||r.length;return o>s?{ok:!1,reason:"too_large",bytes:o,message:`File is larger than the ${Math.round(s/1024)} KB preview limit`}:{ok:!0,text:r,bytes:o,truncated:!1}}catch(r){return{ok:!1,reason:"read_error",message:String((r==null?void 0:r.message)||r)}}}async readImage(e,t={}){let s=Number(t.maxSize)||10485760;if(!this.reader.canRead(e))return{ok:!1,reason:"unreadable",message:"This entry cannot be read"};let i=this.reader.getSize(e);if(i>s)return{ok:!1,reason:"too_large",bytes:i,message:`Image is larger than the ${Math.round(s/(1024*1024))} MB preview limit`};try{let r=await this.reader.displayUrl(e);return r?{ok:!0,url:r,bytes:i}:{ok:!1,reason:"no_url",message:"No preview url available"}}catch(r){return{ok:!1,reason:"read_error",message:String((r==null?void 0:r.message)||r)}}}async getPreview(e){return(e==null?void 0:e.kind)==="text"?{type:"text",...await this.readText(e)}:(e==null?void 0:e.kind)==="image"?{type:"image",...await this.readImage(e)}:{type:"info",ok:!0,message:`${(e==null?void 0:e.name)||"Entry"} \u2014 no inline preview for this type`}}clear(){this.cache.clear()}};function Ee(n){return{async list(e,t={}){let{withStats:s=!0,onProgress:i}=t;return(s?await n.listWithStats(e,{onProgress:i}):await n.list(e)).map(o=>({...o,kind:G(o.name,o.mime,o.isDirectory)}))},stat:e=>n.stat(e),readText:e=>n.readText(e),readBytes:e=>n.readBytes(e),displayUrl:e=>n.displayUrl(e),rename:(e,t)=>n.rename(e,t),move:(e,t)=>n.move(e,t),copy:(e,t)=>n.copy(e,t),remove:e=>n.remove(e),createFile:(e,t,s)=>n.createFile(e,t,s),createDirectory:(e,t)=>n.createDirectory(e,t),openInEditor:e=>n.openInEditor(e)}}var te=class{constructor(e){this.fileOps=e,this.operationId=0}_nextId(){return++this.operationId}async rename(e,t,s={}){let i=[],r=this._nextId();for(let o=0;o<e.length;o++){let c=e[o];try{let l=t(c,o);if(!l||l===c.name){i.push({item:c,index:o,status:"skipped",reason:"no_change"});continue}let h=this._validateName(l);if(!h.ok){i.push({item:c,index:o,status:"error",reason:"invalid_name",message:h.message});continue}if(e.some((d,u)=>u===o?!1:t(d,u)===l)){i.push({item:c,index:o,status:"error",reason:"conflict",message:"Another file in batch would get the same name"});continue}await this.fileOps.rename(c,l,s),i.push({item:c,index:o,status:"ok",oldName:c.name,newName:l})}catch(l){i.push({item:c,index:o,status:"error",reason:"operation_failed",message:String(l)})}}return{operationId:r,total:e.length,results:i,successCount:i.filter(o=>o.status==="ok").length,errorCount:i.filter(o=>o.status==="error").length,skippedCount:i.filter(o=>o.status==="skipped").length}}async changeExtension(e,t,s={}){let i=t.startsWith(".")?t:"."+t;return this.rename(e,r=>{var c;return(((c=r.name)==null?void 0:c.replace(/\.[^.]+$/,""))||r.name)+i},s)}async move(e,t,s={}){let i=[],r=this._nextId();for(let o=0;o<e.length;o++){let c=e[o];try{await this.fileOps.move(c,t,s),i.push({item:c,index:o,status:"ok",targetDir:t})}catch(l){i.push({item:c,index:o,status:"error",reason:"operation_failed",message:String(l)})}}return{operationId:r,total:e.length,results:i,successCount:i.filter(o=>o.status==="ok").length,errorCount:i.filter(o=>o.status==="error").length}}async copy(e,t,s={}){let i=[],r=this._nextId();for(let o=0;o<e.length;o++){let c=e[o];try{await this.fileOps.copy(c,t,s),i.push({item:c,index:o,status:"ok",targetDir:t})}catch(l){i.push({item:c,index:o,status:"error",reason:"operation_failed",message:String(l)})}}return{operationId:r,total:e.length,results:i,successCount:i.filter(o=>o.status==="ok").length,errorCount:i.filter(o=>o.status==="error").length}}async delete(e,t={}){let s=[],i=this._nextId();for(let r=0;r<e.length;r++){let o=e[r];try{await this.fileOps.remove(o,t),s.push({item:o,index:r,status:"ok"})}catch(c){s.push({item:o,index:r,status:"error",reason:"operation_failed",message:String(c)})}}return{operationId:i,total:e.length,results:s,successCount:s.filter(r=>r.status==="ok").length,errorCount:s.filter(r=>r.status==="error").length}}_validateName(e){return!e||typeof e!="string"?{ok:!1,message:"Name is required"}:e.length===0?{ok:!1,message:"Name cannot be empty"}:/[<>:"/\\|?*]/.test(e)?{ok:!1,message:"Name contains invalid characters"}:/^(\.|CON|PRN|AUX|NUL|COM\d|LPT\d)$/i.test(e.trim())?{ok:!1,message:"Name is reserved"}:e.length>255?{ok:!1,message:"Name is too long (max 255 characters)"}:e.endsWith(".")||e.endsWith(" ")?{ok:!1,message:"Name cannot end with dot or space"}:{ok:!0}}createSequentialPattern(e="file",t=1){let s=t;return()=>{let i=`${e}_${String(s).padStart(3,"0")}`;return s++,i}}createSuffixPattern(e="_backup"){return t=>{var r,o;let s=((r=t.name)==null?void 0:r.replace(/\.[^.]+$/,""))||t.name,i=(o=t.name)!=null&&o.includes(".")?"."+t.name.split(".").pop():"";return`${s}${e}${i}`}}createPrefixPattern(e="old_"){return t=>e+(t.name||"")}};var B=class{constructor(e=[]){this.items=e,this._cache=new Map}get files(){if(this._cache.has("files"))return this._cache.get("files");let e=this.items.filter(t=>t.isFile);return this._cache.set("files",e),e}get folders(){if(this._cache.has("folders"))return this._cache.get("folders");let e=this.items.filter(t=>t.isDirectory);return this._cache.set("folders",e),e}bySize(e=10){return this.files.filter(t=>typeof t.size=="number"&&t.size>0).sort((t,s)=>(s.size||0)-(t.size||0)).slice(0,e)}byAge(e=10,t=null){let s=Date.now(),i=this.files.filter(r=>typeof r.modified=="number").sort((r,o)=>(r.modified||0)-(o.modified||0));if(t){let r=s-t;i=i.filter(o=>(o.modified||0)<r)}return i.slice(0,e)}duplicateNames(){return K(this.files)}tempFiles(){return this.files.filter(e=>Y(e.name))}backupFiles(){return this.files.filter(e=>X(e.name))}allCandidates(){let e=new Map;for(let t of this.files){if(!Q(t.name,"file"))continue;let s=[];Y(t.name)&&s.push("temporary"),X(t.name)&&s.push("backup"),s.length>0&&e.set(t.path||t.name,{...t,cleanupReasons:s})}return Array.from(e.values())}summary(){var o,c;let e=this.files,t=this.folders,s=e.reduce((l,h)=>l+(h.size||0),0),i=new Map;for(let l of e){let h=l.kind||"other";i.set(h,(i.get(h)||0)+1)}let r=new Map;for(let l of e){let h=((c=(o=l.name)==null?void 0:o.split(".").pop())==null?void 0:c.toLowerCase())||"no_ext";r.set(h,(r.get(h)||0)+1)}return{totalFiles:e.length,totalFolders:t.length,totalItems:this.items.length,totalSize:s,totalSizeFormatted:g(s),byType:Object.fromEntries(i.entries()),byExtension:Object.fromEntries([...r.entries()].sort((l,h)=>h[1]-l[1]).slice(0,10)),largestFiles:this.bySize(5),oldestFiles:this.byAge(5),hasDuplicates:this.duplicateNames().length>0,duplicateGroups:this.duplicateNames()}}search(e){if(!e||e.trim()==="")return[];let t=e.toLowerCase();return this.items.filter(s=>{var i,r,o;return((i=s.name)==null?void 0:i.toLowerCase().includes(t))||((r=s.path)==null?void 0:r.toLowerCase().includes(t))||((o=s.kind)==null?void 0:o.toLowerCase().includes(t))})}filterByType(e){let t=Array.isArray(e)?e:[e];return this.items.filter(s=>t.includes(s.kind))}filterBySize({min:e=0,max:t=1/0}={}){return this.files.filter(s=>{let i=s.size||0;return i>=e&&i<=t})}filterByDate({since:e=0,until:t=Date.now()}={}){return this.files.filter(s=>{let i=s.modified||0;return i>=e&&i<=t})}clearCache(){this._cache.clear()}refresh(e){this.items=e,this.clearCache()}};var se=class{constructor(e){this.fileOps=e.fileOps,this.access=e.access,this.batch=e.batch,this.preview=e.preview,this.settings=e.settings||null,this.operations=new Map}async open(e){if(!e||e.isDirectory)return!1;try{return!!this.fileOps.open(e)}catch(t){return f(`Could not open ${e.name}`),console.warn("[FS] open failed",t),!1}}async previewEntry(e){return!e||e.isDirectory?{ok:!1,reason:"not_a_file",message:"Folders have no preview"}:await this.preview.getPreview(e)}async copyText(e){var t;try{if((t=navigator.clipboard)!=null&&t.writeText)return await navigator.clipboard.writeText(e),!0}catch{}try{let s=document.createElement("textarea");s.value=e,s.setAttribute("readonly",""),s.style.position="fixed",s.style.opacity="0",document.body.appendChild(s),s.select();let i=document.execCommand("copy");return document.body.removeChild(s),i}catch{return!1}}async copyPath(e){let t=await this.copyText((e==null?void 0:e.url)||(e==null?void 0:e.path)||"");return t&&f("Path copied"),t}async copyName(e){let t=await this.copyText((e==null?void 0:e.name)||"");return t&&f("Name copied"),t}async renameEntry(e,t){var s,i;if(!e||!t||t===e.name||((s=this.settings)==null?void 0:s.get("behavior_confirmDestructive"))!==!1&&!await j("Rename",`Rename "${e.name}" to "${t}"?`))return!1;try{return await this.fileOps.rename(e.url,t),(i=this.access)==null||i.invalidate(e.parent),f(`Renamed to ${t}`),!0}catch(r){return f(`Rename failed: ${(r==null?void 0:r.message)||r}`),!1}}async deleteEntry(e){var t,s;if(!e||((t=this.settings)==null?void 0:t.get("behavior_confirmDestructive"))!==!1&&!await j("Delete",`Delete "${e.name}"? This cannot be undone.`))return!1;try{return await this.fileOps.remove(e.url),(s=this.access)==null||s.invalidate(e.parent),f(`Deleted ${e.name}`),!0}catch(i){return f(`Delete failed: ${(i==null?void 0:i.message)||i}`),!1}}async createFile(e,t="untitled.txt"){var i;let s=await z("New file name",t,"text");if(!s)return!1;try{return await this.fileOps.createFile(e,s,""),(i=this.access)==null||i.invalidate(e),f(`Created ${s}`),!0}catch(r){return f(`Could not create file: ${(r==null?void 0:r.message)||r}`),!1}}async createFolder(e,t="New folder"){var i;let s=await z("New folder name",t,"text");if(!s)return!1;try{return await this.fileOps.createDirectory(e,s),(i=this.access)==null||i.invalidate(e),f(`Created ${s}`),!0}catch(r){return f(`Could not create folder: ${(r==null?void 0:r.message)||r}`),!1}}async moveEntries(e){var r,o;let t=(e||[]).filter(c=>c&&!c.isDirectory);if(!t.length)return f("Select at least one file"),null;let s=await ce();if(!s)return null;let i=await this.batch.move(t,s);for(let c of new Set(t.map(l=>l.parent)))(r=this.access)==null||r.invalidate(c);return(o=this.access)==null||o.invalidate(s),f(`Moved ${i.successCount} of ${i.total}`),i}async copyEntries(e){var r;let t=(e||[]).filter(o=>o&&!o.isDirectory);if(!t.length)return f("Select at least one file"),null;let s=await ce();if(!s)return null;let i=await this.batch.copy(t,s);return(r=this.access)==null||r.invalidate(s),f(`Copied ${i.successCount} of ${i.total}`),i}async deleteEntries(e){var i,r;let t=(e||[]).filter(Boolean);if(!t.length||((i=this.settings)==null?void 0:i.get("behavior_confirmDestructive"))!==!1&&!await j("Delete files",`Delete ${t.length} item(s)? This cannot be undone.`))return null;let s=await this.batch.delete(t);for(let o of new Set(t.map(c=>c.parent)))(r=this.access)==null||r.invalidate(o);return f(`Deleted ${s.successCount} of ${s.total}`),s}async renameEntries(e,t){var i;let s=await this.batch.rename(e||[],t);for(let r of new Set((e||[]).map(o=>o.parent)))(i=this.access)==null||i.invalidate(r);return f(`Renamed ${s.successCount} of ${s.total}`),s}async saveTextFile(e,t,s){var i;if(!e)return{ok:!1,message:"No destination folder"};try{let r=await this.fileOps.createFile(e,t,s);return(i=this.access)==null||i.invalidate(e),{ok:!0,url:typeof r=="string"?r:void 0}}catch(r){return{ok:!1,message:String((r==null?void 0:r.message)||r)}}}async shareText(e,t,s){try{if(typeof navigator>"u"||!navigator.share||typeof File>"u")return!1;let i=new File([e],t,{type:s});return navigator.canShare&&!navigator.canShare({files:[i]})?!1:(await navigator.share({files:[i],title:t}),!0)}catch(i){return(i==null?void 0:i.name)==="AbortError"?!0:(console.warn("[FS] share failed",i),!1)}}async displayUrl(e){try{if(this.fileOps.displayUrl)return await this.fileOps.displayUrl(e)}catch{}return e}summarize(e){return new B(e||[]).summary()}cleanupCandidates(e){var t;return((t=this.settings)==null?void 0:t.get("tools_cleanupEnabled"))===!1?[]:new B(e||[]).allCandidates().sort((s,i)=>(i.size||0)-(s.size||0))}getActionsFor(e){var s;if(!e)return[];if(e.isDirectory)return[{id:"open",label:"Open folder"},{id:"detail",label:"Folder summary"},{id:"rename",label:"Rename folder"},{id:"delete",label:"Delete folder",danger:!0}];let t=[{id:"open",label:"Open in editor"},{id:"preview",label:"Quick preview"},{id:"copy_path",label:"Copy path"},{id:"copy_name",label:"Copy name"},{id:"rename",label:"Rename"}];return((s=this.settings)==null?void 0:s.get("tools_batchEnabled"))!==!1&&t.push({id:"batch",label:"Batch actions"}),t.push({id:"delete",label:"Delete",danger:!0}),t}trackOperation(e,t){this.operations.set(e,{...t,status:"pending",startedAt:Date.now()})}updateOperation(e,t){let s=this.operations.get(e);s&&(s.status=t,s.completedAt=Date.now())}dispose(){var e,t;this.operations.clear(),(t=(e=this.preview)==null?void 0:e.clear)==null||t.call(e)}};var O=new Intl.Collator(void 0,{numeric:!0,sensitivity:"base"});function st(n,e,t){switch(t){case"size":return(n.size||0)-(e.size||0);case"date":return(n.modified||0)-(e.modified||0);case"type":return O.compare(n.kind||"",e.kind||"")||O.compare(n.name||"",e.name||"");default:return O.compare(n.name||"",e.name||"")}}function De(n,e="name",t="asc",s={}){let{foldersFirst:i=!0}=s,r=t==="desc"?-1:1;return[...n||[]].sort((o,c)=>{if(i&&!!o.isDirectory!=!!c.isDirectory)return o.isDirectory?-1:1;let l=st(o,c,e);return l!==0?l*r:O.compare(o.name||"",c.name||"")})}function Te(n){let e=new Map;for(let t of n||[]){let s=t.isDirectory?"folder":t.kind||"other";e.set(s,(e.get(s)||0)+1)}return[...e.entries()].map(([t,s])=>({kind:t,count:s})).sort((t,s)=>s.count-t.count||O.compare(t.kind,s.kind))}var it=2e3,rt='"',ot="'";function y(n){return String(n??"").split("&").join("&amp;").split("<").join("&lt;").split(">").join("&gt;").split(rt).join("&quot;").split(ot).join("&#39;")}function $e(n){let{title:e,parts:t,summary:s,cleanup:i,entries:r,includePaths:o,includeListing:c,now:l}=n,[h,...p]=t,d=i.reduce((w,F)=>w+(F.size||0),0),u=[["Files",v(s.totalFiles)],["Folders",v(s.totalFolders)],["Total size",g(s.totalSize,{precise:!0})],["Duplicate names",s.hasDuplicates?"Yes":"No"]],b=Object.entries(s.byType||{}).sort((w,F)=>F[1]-w[1]),$=s.largestFiles||[],T=r.slice(0,it),m=['<header class="head">',`<h1>${y(e)}</h1>`,`<p class="meta">${p.map(w=>y(w)).join(" \xB7 ")}</p>`,"</header>","",'<section class="cards">',...u.map(([w,F])=>`<div class="card"><span class="k">${y(w)}</span><span class="v">${y(F)}</span></div>`),"</section>"];if(b.length){m.push("","<section>","<h2>Type breakdown</h2>",'<div class="scroll"><table>','<thead><tr><th>Type</th><th class="num">Count</th></tr></thead>',"<tbody>");for(let[w,F]of b)m.push(`<tr><td>${y(C(w))}</td><td class="num">${y(v(F))}</td></tr>`);m.push("</tbody>","</table></div>","</section>")}if($.length){m.push("","<section>","<h2>Largest files</h2>",'<div class="scroll"><table>','<thead><tr><th>File</th><th class="num">Size</th></tr></thead>',"<tbody>");for(let w of $)m.push(`<tr><td class="name">${y(w.name)}</td><td class="num">${y(g(w.size))}</td></tr>`);m.push("</tbody>","</table></div>","</section>")}if(m.push("","<section>","<h2>Cleanup suggestions</h2>"),!i.length)m.push('<p class="note">No temporary or backup files found.</p>');else{m.push('<div class="scroll"><table>','<thead><tr><th>File</th><th>Reason</th><th class="num">Size</th></tr></thead>',"<tbody>");for(let w of i){let F=(w.cleanupReasons||[]).join(", ")||"candidate";m.push(`<tr><td class="name">${y(w.name)}</td><td><span class="badge">${y(F)}</span></td><td class="num">${y(g(w.size))}</td></tr>`)}m.push("</tbody>","</table></div>"),m.push(`<p class="note">Reclaimable: <strong>${y(g(d))}</strong> across ${y(v(i.length))} file(s).</p>`)}if(m.push("</section>"),c){m.push("","<section>","<h2>Files</h2>",'<div class="scroll"><table>',o?'<thead><tr><th>Name</th><th>Type</th><th>Modified</th><th class="num">Size</th><th>Path</th></tr></thead>':'<thead><tr><th>Name</th><th>Type</th><th>Modified</th><th class="num">Size</th></tr></thead>',"<tbody>");for(let w of T){let F=w.isDirectory?"folder":C(w.kind).toLowerCase(),Ve=w.isDirectory?"\u2014":g(w.size),xe=[`<td class="name">${y(w.name)}</td>`,`<td><span class="kind">${y(F)}</span></td>`,`<td class="date">${y(E(w.modified))}</td>`,`<td class="num">${y(Ve)}</td>`];o&&xe.push(`<td class="path">${y(w.url||"")}</td>`),m.push(`<tr>${xe.join("")}</tr>`)}m.push("</tbody>","</table></div>"),r.length>T.length&&m.push(`<p class="note">\u2026 and ${y(v(r.length-T.length))} more.</p>`),m.push("</section>")}return m.push("",'<footer class="foot">',"<span>Generated by FS \u2014 Folder Workspace</span>",`<span>${y(E(l))}</span>`,"</footer>"),["<!doctype html>",'<html lang="en">',"<head>",'<meta charset="utf-8">','<meta name="viewport" content="width=device-width, initial-scale=1">',`<title>${y(h)}</title>`,"<style>",nt,"</style>","</head>","<body>",'<main class="page">',...m,"</main>","</body>","</html>"].join(`
`)}var nt=`
:root {
  color-scheme: light dark;
  --bg: #ffffff;
  --fg: #1c1d21;
  --muted: #5c6070;
  --border: #e2e4ea;
  --card: #f6f7fa;
  --warn: #8a4b00;
  --warn-bg: #fff3e0;
}
@media (prefers-color-scheme: dark) {
  :root {
    --bg: #16171a;
    --fg: #e8e8ea;
    --muted: #a8acb8;
    --border: #2c2f36;
    --card: #1e2026;
    --warn: #ffc078;
    --warn-bg: #3a2c17;
  }
}
* { box-sizing: border-box; }
body {
  margin: 0;
  background: var(--bg);
  color: var(--fg);
  font: 15px/1.5 -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
  -webkit-text-size-adjust: 100%;
}
.page { max-width: 1020px; margin: 0 auto; padding: 24px 18px 48px; }
.head h1 { margin: 0 0 4px; font-size: 24px; line-height: 1.25; word-break: break-word; }
.meta { margin: 0; color: var(--muted); font-size: 13px; }
.cards {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(140px, 1fr));
  gap: 10px;
  margin: 22px 0 8px;
}
.card {
  background: var(--card);
  border: 1px solid var(--border);
  border-radius: 10px;
  padding: 12px 14px;
  display: flex;
  flex-direction: column;
  gap: 2px;
}
.card .k { color: var(--muted); font-size: 12px; text-transform: uppercase; letter-spacing: .04em; }
.card .v { font-size: 20px; font-weight: 600; }
section { margin-top: 28px; }
h2 { font-size: 15px; text-transform: uppercase; letter-spacing: .05em; color: var(--muted); margin: 0 0 10px; }
.scroll { overflow-x: auto; -webkit-overflow-scrolling: touch; }
table { width: 100%; border-collapse: collapse; font-size: 14px; }
th, td { text-align: left; padding: 8px 10px; border-bottom: 1px solid var(--border); vertical-align: top; }
th { font-size: 12px; text-transform: uppercase; letter-spacing: .04em; color: var(--muted); font-weight: 600; white-space: nowrap; }
tbody tr:nth-child(even) { background: var(--card); }
.num { text-align: right; white-space: nowrap; font-variant-numeric: tabular-nums; }
.date { white-space: nowrap; color: var(--muted); }
.name { word-break: break-word; }
.path { color: var(--muted); font-size: 12px; word-break: break-all; }
.kind { font-size: 11px; text-transform: uppercase; letter-spacing: .04em; color: var(--muted); }
.badge {
  display: inline-block;
  padding: 1px 8px;
  border-radius: 999px;
  font-size: 12px;
  color: var(--warn);
  background: var(--warn-bg);
}
.note { color: var(--muted); font-size: 13px; margin: 10px 0 0; }
.foot {
  margin-top: 36px;
  padding-top: 14px;
  border-top: 1px solid var(--border);
  color: var(--muted);
  font-size: 12px;
  display: flex;
  justify-content: space-between;
  gap: 12px;
  flex-wrap: wrap;
}
@media print {
  body { background: #fff; color: #000; }
  .cards { grid-template-columns: repeat(4, 1fr); }
  section { break-inside: avoid; }
}
`;var _e=[{value:"text",label:"Plain text",extension:"txt",mime:"text/plain"},{value:"markdown",label:"Markdown",extension:"md",mime:"text/markdown"},{value:"csv",label:"CSV",extension:"csv",mime:"text/csv"},{value:"html",label:"HTML page",extension:"html",mime:"text/html"}],Me=10,Ne=2e3,N='"',P=`
`,at="\r",Be="|",lt="\\";function ue(n){return _e.find(e=>e.value===n)||_e[0]}function Le(n){let{rootTitle:e="folder",rootUrl:t="",entries:s=[],format:i="text",includePaths:r=!1,includeListing:o=!0,now:c=Date.now()}=n||{},l=new B(s),h=(n==null?void 0:n.summary)||l.summary(),p=(n==null?void 0:n.cleanup)||l.allCandidates();if(i==="csv")return dt(s,r);let d=[`${e} \u2014 folder report`,`Generated ${E(c)}`];return r&&t&&d.push(`Location ${t}`),i==="html"?$e({title:e,parts:d,summary:h,cleanup:p,entries:s,includePaths:r,includeListing:o,now:c}):`${i==="markdown"?ht(d,h,p,s,r,o):ct(d,h,p,s,r,o)}${P}`}function ct(n,e,t,s,i,r){let o=[n[0],...n.slice(1)];o.push(""),o.push("SUMMARY"),o.push(D("  Files",18)+e.totalFiles),o.push(D("  Folders",18)+e.totalFolders),o.push(D("  Total size",18)+g(e.totalSize,{precise:!0})),o.push(D("  Duplicate names",18)+(e.hasDuplicates?"yes":"no"));let c=Object.entries(e.byType||{});if(c.length){o.push(""),o.push("TYPE BREAKDOWN");for(let[h,p]of c.sort((d,u)=>u[1]-d[1]))o.push(D(`  ${C(h)}`,18)+p)}let l=(e.largestFiles||[]).slice(0,Me);if(l.length){o.push(""),o.push("LARGEST FILES");for(let h of l)o.push(`  ${D(g(h.size),10)} ${h.name}`)}if(o.push(""),o.push("CLEANUP SUGGESTIONS"),!t.length)o.push("  None found.");else{let h=t.reduce((p,d)=>p+(d.size||0),0);for(let p of t){let d=(p.cleanupReasons||[]).join(", ")||"candidate";o.push(`  ${D(g(p.size),10)} ${D(p.name,30)} (${d})`)}o.push(`  Reclaimable: ${g(h)} across ${t.length} file(s)`)}if(r){o.push(""),o.push("FILES");let h=s.slice(0,Ne),p=Math.max(6,...h.map(d=>g(d.size).length));for(let d of h){let u=d.isDirectory?"folder":C(d.kind).toLowerCase();o.push(`  ${D(d.isDirectory?"\u2014":g(d.size),p)}  ${D(E(d.modified),20)}  ${D(u,8)}  ${d.name}`+(i?`  ${d.url||""}`:""))}s.length>h.length&&o.push(`  \u2026 and ${s.length-h.length} more`)}return o.join(P)}function ht(n,e,t,s,i,r){let[o,...c]=n,l=[`# ${o}`,"",...c.map(d=>`_${d}_`),""];l.push("## Summary",""),l.push("| Metric | Value |","| --- | --- |"),l.push(`| Files | ${e.totalFiles} |`),l.push(`| Folders | ${e.totalFolders} |`),l.push(`| Total size | ${g(e.totalSize,{precise:!0})} |`),l.push(`| Duplicate names | ${e.hasDuplicates?"yes":"no"} |`),l.push("");let h=Object.entries(e.byType||{});if(h.length){l.push("## Type breakdown",""),l.push("| Type | Count |","| --- | --- |");for(let[d,u]of h.sort((b,$)=>$[1]-b[1]))l.push(`| ${C(d)} | ${u} |`);l.push("")}let p=(e.largestFiles||[]).slice(0,Me);if(p.length){l.push("## Largest files",""),l.push("| Size | File |","| --- | --- |");for(let d of p)l.push(`| ${g(d.size)} | ${ie(d.name)} |`);l.push("")}if(l.push("## Cleanup suggestions",""),!t.length)l.push("None found.","");else{let d=t.reduce((u,b)=>u+(b.size||0),0);l.push("| Size | File | Reason |","| --- | --- | --- |");for(let u of t){let b=(u.cleanupReasons||[]).join(", ")||"candidate";l.push(`| ${g(u.size)} | ${ie(u.name)} | ${b} |`)}l.push(""),l.push(`Reclaimable: **${g(d)}** across ${t.length} file(s).`,"")}if(r){let d=s.slice(0,Ne);l.push("## Files",""),l.push(i?"| Size | Modified | Type | Name | Path |":"| Size | Modified | Type | Name |",i?"| --- | --- | --- | --- | --- |":"| --- | --- | --- | --- |");for(let u of d){let b=u.isDirectory?"folder":C(u.kind).toLowerCase(),T=`${u.isDirectory?"\u2014":g(u.size)} | ${E(u.modified)} | ${b} | ${ie(u.name)}`;l.push(i?`| ${T} | ${ie(u.url||"")} |`:`| ${T} |`)}l.push(""),s.length>d.length&&l.push(`_\u2026 and ${s.length-d.length} more._`,"")}return l.join(P)}function dt(n,e){let t=["name","type","size_bytes","size","modified","isDirectory"];e&&t.push("path");let s=n.map(i=>{let r=[i.name,i.isDirectory?"folder":i.kind||"unknown",i.isDirectory?"":i.size||0,i.isDirectory?"":g(i.size),i.modified?new Date(i.modified).toISOString():"",i.isDirectory?"true":"false"];return e&&r.push(i.url||""),r.map(pt).join(",")});return[t.join(","),...s].join(P)}function pt(n){let e=n==null?"":String(n);return e.includes(",")||e.includes(N)||e.includes(P)||e.includes(at)?N+e.split(N).join(N+N)+N:e}function ie(n){return String(n??"").split(Be).join(lt+Be)}function D(n,e){let t=String(n??"");return t.length>=e?t:t+" ".repeat(e-t.length)}function oe(n,e,t=Date.now()){let s=String(n||"folder").replace(/[^A-Za-z0-9._-]+/g,"-").replace(/^-+|-+$/g,"").slice(0,40)||"folder",i=new Date(t),r=[i.getFullYear(),re(i.getMonth()+1),re(i.getDate()),"-",re(i.getHours()),re(i.getMinutes())].join("");return`${s}-report-${r}.${ue(e).extension}`}function re(n){return String(n).padStart(2,"0")}function a(n,e={},t=[]){let s=document.createElement(n);for(let[i,r]of Object.entries(e))if(r!=null)if(i==="class")s.className=String(r);else if(i==="text")s.textContent=String(r);else if(i==="html")s.innerHTML=String(r);else if(i==="style"&&typeof r=="object")Object.assign(s.style,r);else if(i==="dataset"&&typeof r=="object")Object.assign(s.dataset,r);else if(i==="on"&&typeof r=="object")for(let[o,c]of Object.entries(r))s.addEventListener(o,c);else if(i==="aria"&&typeof r=="object")for(let[o,c]of Object.entries(r))c!=null&&s.setAttribute(`aria-${o}`,String(c));else s[i]=r;return ft(s,t),s}function ft(n,e){for(let t of e||[])t==null||t===!1||n.appendChild(t);return n}function M(n){for(;n.firstChild;)n.removeChild(n.firstChild);return n}function k(n,e=""){return a("span",{class:`fs-ic ${e}`.trim(),html:Re[n]||Re.file,aria:{hidden:"true"}})}var Re={folder:'<svg viewBox="0 0 24 24" fill="currentColor"><path d="M10 4H4a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-8l-2-2z"/></svg>',file:'<svg viewBox="0 0 24 24" fill="currentColor"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8l-6-6zm0 2.5L17.5 8H14V4.5z"/></svg>',text:'<svg viewBox="0 0 24 24" fill="currentColor"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8l-6-6zM8 13h8v1.5H8V13zm0 3h8v1.5H8V16zm0-6h4v1.5H8V10z"/></svg>',image:'<svg viewBox="0 0 24 24" fill="currentColor"><path d="M21 19V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2zM8.5 13.5l2.5 3 3.5-4.5 4.5 6H5l3.5-4.5z"/></svg>',media:'<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 3v10.55A4 4 0 1 0 14 17V7h4V3h-6z"/></svg>',archive:'<svg viewBox="0 0 24 24" fill="currentColor"><path d="M4 4h16v4H4V4zm0 6h16v10H4V10zm6 2h4v2h-4v-2z"/></svg>',search:'<svg viewBox="0 0 24 24" fill="currentColor"><path d="M15.5 14h-.79l-.28-.27A6.47 6.47 0 0 0 16 9.5 6.5 6.5 0 1 0 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0A4.5 4.5 0 1 1 14 9.5 4.5 4.5 0 0 1 9.5 14z"/></svg>',sort:'<svg viewBox="0 0 24 24" fill="currentColor"><path d="M3 18h6v-2H3v2zM3 6v2h18V6H3zm0 7h12v-2H3v2z"/></svg>',refresh:'<svg viewBox="0 0 24 24" fill="currentColor"><path d="M17.65 6.35A8 8 0 1 0 19.73 14h-2.08A6 6 0 1 1 12 6a5.94 5.94 0 0 1 4.22 1.78L13 11h7V4l-2.35 2.35z"/></svg>',close:'<svg viewBox="0 0 24 24" fill="currentColor"><path d="M19 6.41 17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/></svg>',chevron:'<svg viewBox="0 0 24 24" fill="currentColor"><path d="M9.29 6.71 4 12l5.29 5.29 1.42-1.42L6.83 12l3.88-3.88z"/></svg>',more:'<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 8a2 2 0 1 0 0-4 2 2 0 0 0 0 4zm0 2a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm0 6a2 2 0 1 0 0 4 2 2 0 0 0 0-4z"/></svg>',check:'<svg viewBox="0 0 24 24" fill="currentColor"><path d="M9 16.17 4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41L9 16.17z"/></svg>',info:'<svg viewBox="0 0 24 24" fill="currentColor"><path d="M11 7h2v2h-2V7zm0 4h2v6h-2v-6zm1-9a10 10 0 1 0 0 20 10 10 0 0 0 0-20zm0 18a8 8 0 1 1 0-16 8 8 0 0 1 0 16z"/></svg>',eye:'<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 4.5C7 4.5 2.73 7.61 1 12c1.73 4.39 6 7.5 11 7.5s9.27-3.11 11-7.5c-1.73-4.39-6-7.5-11-7.5zm0 12a4.5 4.5 0 1 1 0-9 4.5 4.5 0 0 1 0 9z"/></svg>',edit:'<svg viewBox="0 0 24 24" fill="currentColor"><path d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04a1 1 0 0 0 0-1.41l-2.34-2.34a1 1 0 0 0-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z"/></svg>',trash:'<svg viewBox="0 0 24 24" fill="currentColor"><path d="M6 19a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"/></svg>',copy:'<svg viewBox="0 0 24 24" fill="currentColor"><path d="M16 1H4a2 2 0 0 0-2 2v14h2V3h12V1zm3 4H8a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h11a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2z"/></svg>',move:'<svg viewBox="0 0 24 24" fill="currentColor"><path d="M10 9h4V6h3l-5-5-5 5h3v3zm-1 1H6V7l-5 5 5 5v-3h3v-4zm14 2-5-5v3h-3v4h3v3l5-5zm-9 3h-4v3H7l5 5 5-5h-3v-3z"/></svg>',plus:'<svg viewBox="0 0 24 24" fill="currentColor"><path d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z"/></svg>',select:'<svg viewBox="0 0 24 24" fill="currentColor"><path d="M3 5h2V3a2 2 0 0 0-2 2zm0 8h2v-2H3v2zm4 8h2v-2H7v2zM3 9h2V7H3v2zm10-6h-2v2h2V3zm6 0v2h2a2 2 0 0 0-2-2zM5 21v-2H3a2 2 0 0 0 2 2zm-2-4h2v-2H3v2zm8 4h2v-2h-2v2zm8-8h2v-2h-2v2zm0-8h-2v2h2V3zm0 12h-2v2a2 2 0 0 0 2-2zm-8-8h-2v2h2V7zm0 8h-2v2h2v-2zm4-8h-2v2h2V7zm0 8h-2v2h2v-2z"/></svg>',back:'<svg viewBox="0 0 24 24" fill="currentColor"><path d="M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z"/></svg>',expand:'<svg viewBox="0 0 24 24" fill="currentColor"><path d="M7 14H5v5h5v-2H7v-3zm-2-4h2V7h3V5H5v5zm12 7h-3v2h5v-5h-2v3zM14 5v2h3v3h2V5h-5z"/></svg>',compress:'<svg viewBox="0 0 24 24" fill="currentColor"><path d="M5 16h3v3h2v-5H5v2zm3-8H5v2h5V5H8v3zm6 11h2v-3h3v-2h-5v5zm2-11V5h-2v5h5V8h-3z"/></svg>'};var me="acode-fs-util-styles",Ie=`
.fs-root {
  --fs-bg: var(--popup-background-color, var(--secondary-color, #1e1f22));
  --fs-fg: var(--popup-text-color, var(--primary-text-color, #e6e6e6));
  --fs-muted: var(--secondary-text-color, #9a9a9a);
  --fs-border: var(--border-color, rgba(128, 128, 128, 0.35));
  --fs-accent: var(--primary-color, #4c8bf5);
  --fs-danger: var(--danger-color, #e05252);
  --fs-hover: var(--active-color, rgba(128, 128, 128, 0.16));
  --fs-radius: 10px;

  position: fixed;
  z-index: 960;
  display: flex;
  flex-direction: column;
  background: var(--fs-bg);
  color: var(--fs-fg);
  font-size: 14px;
  line-height: 1.4;
  -webkit-tap-highlight-color: transparent;
}

.fs-root * { box-sizing: border-box; }

/* ---- Placement -------------------------------------------------------- */

.fs-root.fs-mode-mobile {
  inset: 0;
  width: 100%;
  height: 100%;
}

.fs-root.fs-mode-desktop {
  top: 0;
  bottom: 0;
  max-width: 92vw;
  width: 420px;
  border-inline-start: 1px solid var(--fs-border);
  box-shadow: 0 0 24px rgba(0, 0, 0, 0.35);
}
.fs-root.fs-mode-desktop.fs-side-right { right: 0; }
.fs-root.fs-mode-desktop.fs-side-left {
  left: 0;
  border-inline-start: none;
  border-inline-end: 1px solid var(--fs-border);
}

.fs-root[hidden] { display: none !important; }

.fs-scrim {
  position: fixed;
  inset: 0;
  z-index: 950;
  background: rgba(0, 0, 0, 0.45);
}
.fs-scrim[hidden] { display: none !important; }

/* Drag handle: only meaningful for the docked layout. */
.fs-resizer {
  position: absolute;
  top: 0;
  bottom: 0;
  width: 14px;
  cursor: col-resize;
  touch-action: none;
  display: none;
}
.fs-root.fs-mode-desktop.fs-side-right .fs-resizer { left: -7px; }
.fs-root.fs-mode-desktop.fs-side-left .fs-resizer { right: -7px; }
.fs-root.fs-mode-desktop .fs-resizer { display: block; }
.fs-resizer::after {
  content: "";
  position: absolute;
  top: 0;
  bottom: 0;
  left: 6px;
  width: 2px;
  background: transparent;
  transition: background 120ms ease;
}
.fs-resizer:hover::after,
.fs-resizer.fs-dragging::after { background: var(--fs-accent); }

/* ---- Header ----------------------------------------------------------- */

.fs-header {
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 8px 10px;
  border-bottom: 1px solid var(--fs-border);
  flex: 0 0 auto;
}

.fs-title {
  flex: 1 1 auto;
  min-width: 0;
  display: flex;
  flex-direction: column;
}
.fs-title strong {
  font-size: 14px;
  font-weight: 600;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.fs-title span {
  font-size: 11px;
  color: var(--fs-muted);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.fs-btn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 4px;
  min-width: 34px;
  height: 34px;
  padding: 0 8px;
  border: 1px solid transparent;
  border-radius: 8px;
  background: transparent;
  color: inherit;
  font: inherit;
  cursor: pointer;
}
.fs-btn:hover { background: var(--fs-hover); }
.fs-btn:active { transform: scale(0.96); }
.fs-btn[aria-pressed="true"] {
  background: var(--fs-hover);
  border-color: var(--fs-border);
}
.fs-btn.fs-danger { color: var(--fs-danger); }
.fs-btn[disabled] { opacity: 0.45; cursor: default; }
.fs-btn:focus-visible,
.fs-row:focus-visible,
.fs-chip:focus-visible,
.fs-input:focus-visible {
  outline: 2px solid var(--fs-accent);
  outline-offset: 1px;
}

.fs-ic { display: inline-flex; width: 18px; height: 18px; flex: 0 0 auto; }
.fs-ic svg { width: 100%; height: 100%; }

/* ---- Search + filters ------------------------------------------------- */

.fs-search {
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 8px 10px 4px;
  flex: 0 0 auto;
}
.fs-input {
  flex: 1 1 auto;
  min-width: 0;
  height: 36px;
  padding: 0 10px;
  border-radius: 8px;
  border: 1px solid var(--fs-border);
  background: transparent;
  color: inherit;
  font: inherit;
}

.fs-chips {
  display: flex;
  gap: 6px;
  padding: 6px 10px 8px;
  overflow-x: auto;
  flex: 0 0 auto;
  scrollbar-width: none;
}
.fs-chips::-webkit-scrollbar { display: none; }
.fs-chip {
  flex: 0 0 auto;
  padding: 4px 10px;
  border-radius: 999px;
  border: 1px solid var(--fs-border);
  background: transparent;
  color: inherit;
  font: inherit;
  font-size: 12px;
  cursor: pointer;
}
.fs-chip[aria-pressed="true"] {
  background: var(--fs-accent);
  border-color: var(--fs-accent);
  color: #fff;
}

/* ---- List ------------------------------------------------------------- */

.fs-body {
  flex: 1 1 auto;
  overflow: auto;
  overscroll-behavior: contain;
  -webkit-overflow-scrolling: touch;
}

.fs-summary {
  display: flex;
  gap: 10px;
  flex-wrap: wrap;
  padding: 6px 12px;
  font-size: 11px;
  color: var(--fs-muted);
  border-bottom: 1px solid var(--fs-border);
}

.fs-list { list-style: none; margin: 0; padding: 0; }

.fs-row {
  display: grid;
  grid-template-columns: auto 1fr auto auto;
  align-items: center;
  gap: 8px;
  width: 100%;
  min-height: 46px;
  padding: 6px 10px;
  border: 0;
  border-bottom: 1px solid var(--fs-border);
  background: transparent;
  color: inherit;
  font: inherit;
  text-align: start;
  cursor: pointer;
}
.fs-row:hover { background: var(--fs-hover); }
.fs-row.fs-selected { background: var(--fs-hover); }
.fs-row[data-kind="folder"] .fs-name { font-weight: 600; }

.fs-main { min-width: 0; display: flex; flex-direction: column; }
.fs-name {
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.fs-meta {
  font-size: 11px;
  color: var(--fs-muted);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.fs-size { font-size: 12px; color: var(--fs-muted); white-space: nowrap; }
.fs-kind {
  font-size: 10px;
  text-transform: uppercase;
  letter-spacing: 0.04em;
  color: var(--fs-muted);
}

.fs-root.fs-compact .fs-row { min-height: 36px; padding: 3px 10px; }
.fs-root.fs-hide-size .fs-size,
.fs-root.fs-hide-kind .fs-kind,
.fs-root.fs-hide-icons .fs-ic { display: none; }
.fs-root.fs-hide-modified .fs-meta-modified { display: none; }

.fs-empty {
  padding: 28px 16px;
  text-align: center;
  color: var(--fs-muted);
}

.fs-kv {
  display: grid;
  grid-template-columns: 1fr auto;
  gap: 4px 12px;
  font-size: 13px;
}
.fs-kv dt { color: var(--fs-muted); }
.fs-kv dd { margin: 0; text-align: end; }

.fs-section { padding: 12px; border-bottom: 1px solid var(--fs-border); }
.fs-section h3 {
  margin: 0 0 8px;
  font-size: 12px;
  text-transform: uppercase;
  letter-spacing: 0.05em;
  color: var(--fs-muted);
}

.fs-preview {
  padding: 12px;
  white-space: pre-wrap;
  word-break: break-word;
  font-family: var(--editor-font, ui-monospace, monospace);
  font-size: 12px;
}
.fs-preview img {
  max-width: 100%;
  max-height: 60vh;
  display: block;
  margin: 0 auto;
  border-radius: 8px;
}

/* ---- Footer / batch bar ---------------------------------------------- */

.fs-footer {
  display: flex;
  align-items: center;
  gap: 8px;
  flex: 0 0 auto;
  padding: 6px 10px;
  border-top: 1px solid var(--fs-border);
  font-size: 11px;
  color: var(--fs-muted);
}
.fs-footer .fs-btn { min-width: 30px; height: 30px; }

.fs-batch {
  display: flex;
  gap: 6px;
  padding: 6px 10px;
  border-top: 1px solid var(--fs-border);
  overflow-x: auto;
  flex: 0 0 auto;
}
.fs-batch[hidden] { display: none; }
.fs-batch .fs-btn {
  height: 32px;
  border-color: var(--fs-border);
  font-size: 12px;
  white-space: nowrap;
}

.fs-progress {
  height: 2px;
  background: var(--fs-accent);
  width: 0;
  transition: width 160ms ease;
  flex: 0 0 auto;
}

/* ---- Report page ------------------------------------------------------ */

.fs-report {
  display: flex;
  flex-direction: column;
  height: 100%;
  min-height: 0;
}
.fs-report-bar {
  display: flex;
  gap: 6px;
  padding: 6px 10px;
  border-bottom: 1px solid var(--fs-border);
  overflow-x: auto;
  flex: 0 0 auto;
}
.fs-report-bar .fs-btn {
  height: 36px;
  border-color: var(--fs-border);
  font-size: 12px;
  white-space: nowrap;
}
.fs-report-frame {
  flex: 1 1 auto;
  width: 100%;
  min-height: 0;
  border: 0;
  background: transparent;
}

@media (max-width: 480px) {
  .fs-row { grid-template-columns: auto 1fr auto; }
  .fs-row .fs-size { display: none; }
}
`;var ut=500,Ae=300,mt=760,gt={folder:"folder",text:"text",image:"image",media:"media",binary:"archive",other:"file",unknown:"file"},ne=class{constructor(e){this.settings=e.settings,this.access=e.access,this.scanner=e.scanner,this.actions=e.actions,this.preview=e.preview,this.rootUrl=null,this.rootTitle="",this.entries=[],this.visible=[],this.query="",this.kindFilter="all",this.selection=new Set,this.selecting=!1,this.view="list",this.previewEntry=null,this.previewData=null,this.reportContent="",this.reportFileName="",this.loading=!1,this.progress={done:0,total:0},this.open=!1,this.disposers=[],this.backGuardPushed=!1,this.element=this.buildShell(),this.scrim=a("div",{class:"fs-scrim",hidden:!0}),this.disposers.push(this.settings.subscribe(()=>{this.applySettings(),this.renderBody(),this.renderChips(),this.applyLayout()}))}buildShell(){return this.searchInput=a("input",{class:"fs-input",type:"search",placeholder:"Filter files",aria:{label:"Filter files in this folder"},on:{input:()=>this.onSearchInput()}}),this.titleName=a("strong",{text:"Folder workspace"}),this.titlePath=a("span",{text:"No folder selected"}),this.detailBtn=this.button("info","Folder summary",()=>this.showDetail()),this.sortBtn=this.button("sort","Change sorting",()=>this.pickSort()),this.refreshBtn=this.button("refresh","Refresh folder",()=>this.refresh()),this.selectBtn=this.button("select","Select files",()=>this.toggleSelecting()),this.moreBtn=this.button("more","More actions",e=>this.showFolderMenu(e)),this.closeBtn=this.button("close","Close folder workspace",()=>this.hide()),this.header=a("header",{class:"fs-header"},[this.closeBtn,a("div",{class:"fs-title"},[this.titleName,this.titlePath]),this.detailBtn,this.sortBtn,this.selectBtn,this.refreshBtn,this.moreBtn]),this.chips=a("div",{class:"fs-chips",role:"toolbar",aria:{label:"Filter by type"}}),this.body=a("div",{class:"fs-body",tabindex:"-1"}),this.progressBar=a("div",{class:"fs-progress"}),this.footerText=a("span",{text:"Ready"}),this.footer=a("footer",{class:"fs-footer"},[this.footerText]),this.batchMoveBtn=this.button("move","Move selected",()=>this.actions.moveEntries(this.selectedEntries()),"fs-btn"),this.batchCopyBtn=this.button("copy","Copy selected",()=>this.actions.copyEntries(this.selectedEntries()),"fs-btn"),this.batchRenameBtn=this.button("edit","Rename selected",()=>this.runBatchRename(),"fs-btn"),this.batchDeleteBtn=this.button("trash","Delete selected",()=>this.runBatchDelete(),"fs-btn fs-danger"),this.batchCancelBtn=this.button("close","Clear selection",()=>this.clearSelection(),"fs-btn"),this.batchBar=a("div",{class:"fs-batch",hidden:!0},[this.batchMoveBtn,this.batchCopyBtn,this.batchRenameBtn,this.batchDeleteBtn,this.batchCancelBtn]),this.resizer=a("div",{class:"fs-resizer",role:"separator",aria:{orientation:"vertical",label:"Resize folder panel"},title:"Drag to resize"}),this.bindResizer(),this.element=a("div",{class:"fs-root",role:"dialog",aria:{modal:"false",label:"Folder workspace"},hidden:!0},[this.resizer,this.header,a("div",{class:"fs-search"},[k("search"),this.searchInput]),this.chips,this.body,this.batchBar,this.progressBar,this.footer]),this.element.addEventListener("keydown",e=>{e.key==="Escape"&&this.open&&this.hide()}),this.element}button(e,t,s,i="fs-btn"){return a("button",{class:i,type:"button",title:t,aria:{label:t},on:{click:s}},[k(e)])}mount(e=document.body){ge(),this.scrim.isConnected||document.body.appendChild(this.scrim),this.element.isConnected||e.appendChild(this.element),this.disposers.push(ke(()=>{this.applyLayout()})),this.scrim.addEventListener("click",()=>this.hide()),window.addEventListener("popstate",this.onPopState=()=>{this.open&&this.hide({skipHistory:!0})})}async show(e={}){if(this.open=!0,this.element.hidden=!1,this.applySettings(),this.applyLayout(),this.isMobile()){this.scrim.hidden=!1;try{window.history.pushState({fsPanel:!0},""),this.backGuardPushed=!0}catch{this.backGuardPushed=!1}}if(!this.rootUrl&&this.settings.get("folder_rememberLast")!==!1){let t=this.settings.get(S.lastFolder),s=this.settings.get(S.lastFolderTitle);t&&(this.rootUrl=t),s&&(this.rootTitle=s)}if(!this.rootUrl&&(await this.chooseFolder(),!this.rootUrl)){this.hide();return}await this.refresh(),e.focus!==!1&&this.body.focus()}hide(e={}){if(this.open)if(this.open=!1,this.element.hidden=!0,this.scrim.hidden=!0,this.progressWidth(0),this.backGuardPushed&&!e.skipHistory){this.backGuardPushed=!1;try{window.history.back()}catch{}}else this.backGuardPushed=!1}toggle(){this.open?this.hide():this.show()}destroy(){var e,t;for(let s of this.disposers)try{s()}catch{}this.disposers=[],this.onPopState&&window.removeEventListener("popstate",this.onPopState),this.scrim.remove(),this.element.remove(),(t=(e=this.actions)==null?void 0:e.dispose)==null||t.call(e)}isMobile(){return ve(this.settings.get("layout_mode","auto")).mode==="mobile"}applyLayout(){let e=this.settings.get("layout_mode","auto"),t=this.settings.get("layout_side","right")==="left"?"left":"right",s=this.isMobile();if(this.element.classList.toggle("fs-mode-mobile",s),this.element.classList.toggle("fs-mode-desktop",!s),this.element.classList.toggle("fs-side-right",t==="right"),this.element.classList.toggle("fs-side-left",t==="left"),this.element.setAttribute("aria-modal",s?"true":"false"),s)this.element.style.width="";else{let i=V(Number(this.settings.get(S.panelWidth))||420);this.element.style.width=`${i}px`,this.element.style[t==="left"?"right":"left"]="auto"}this.scrim.hidden=!this.open||!s}bindResizer(){let e=null,t=i=>{if(e==null||i.pointerId!==e)return;let o=(this.settings.get("layout_side","right")==="left"?"left":"right")==="left"?i.clientX:window.innerWidth-i.clientX;this.element.style.width=`${V(o)}px`},s=i=>{if(e==null||i.pointerId!==e)return;e=null,this.resizer.classList.remove("fs-dragging");try{this.resizer.releasePointerCapture(i.pointerId)}catch{}window.removeEventListener("pointermove",t),window.removeEventListener("pointerup",s),window.removeEventListener("pointercancel",s);let r=Math.round(this.element.getBoundingClientRect().width);this.settings.set(S.panelWidth,V(r),{silent:!0})};this.resizer.addEventListener("pointerdown",i=>{if(!this.isMobile()){e=i.pointerId,this.resizer.classList.add("fs-dragging");try{this.resizer.setPointerCapture(i.pointerId)}catch{}window.addEventListener("pointermove",t),window.addEventListener("pointerup",s),window.addEventListener("pointercancel",s),i.preventDefault()}}),this.resizer.addEventListener("keydown",i=>{let r=Math.round(this.element.getBoundingClientRect().width)||420,o=i.shiftKey?40:16;i.key==="ArrowLeft"?(this.settings.set(S.panelWidth,V(r+o),{silent:!0}),this.applyLayout(),i.preventDefault()):i.key==="ArrowRight"&&(this.settings.set(S.panelWidth,V(r-o),{silent:!0}),this.applyLayout(),i.preventDefault())})}async chooseFolder(){let e=await _();e&&(this.rootUrl=e.url,this.rootTitle=e.title,this.selection.clear(),this.selecting=!1,this.view="list",this.settings.set(S.lastFolder,this.rootUrl,{silent:!0}),this.settings.set(S.lastFolderTitle,this.rootTitle,{silent:!0}))}async openRoot(e,t=""){e&&(this.rootUrl=e,this.rootTitle=t||L(e),this.selection.clear(),this.selecting=!1,this.kindFilter="all",this.view="list",this.settings.set(S.lastFolder,this.rootUrl,{silent:!0}),this.settings.set(S.lastFolderTitle,this.rootTitle,{silent:!0}),await this.refresh())}currentRoot(){return this.rootUrl}async refresh(){if(this.rootUrl){this.loading=!0,this.progress={done:0,total:0},this.footerText.textContent="Scanning\u2026",this.titleName.textContent=this.rootTitle||L(this.rootUrl),this.titlePath.textContent=this.rootUrl,this.renderBody();try{this.access.invalidate(this.rootUrl);let e=await this.scanner.getFiles(this.rootUrl,{recursive:this.settings.get("folder_recursive")===!0,hideIgnored:!0,includeFolders:!0,includeFiles:!0,limit:Number(this.settings.get("folder_maxFiles"))||5e3,maxDepth:Number(this.settings.get("folder_maxDepth"))||3,onProgress:(t,s)=>this.onScanProgress(t,s)});this.entries=this.settings.get("display_showHidden")===!0?e:e.filter(t=>!t.name.startsWith(".")),this.applyFilterAndSort(),this.footerText.textContent=this.statusLine()}catch(e){this.entries=[],this.visible=[],this.footerText.textContent=`Could not read folder: ${(e==null?void 0:e.message)||e}`}finally{this.loading=!1,this.progressWidth(0),this.renderChips(),this.renderBody()}}}onScanProgress(e,t){this.progress={done:e,total:t},this.progressWidth(t?e/t:0)}progressWidth(e){this.progressBar.style.width=`${Math.max(0,Math.min(1,e))*100}%`}applyFilterAndSort(){let e=this.entries;this.kindFilter!=="all"&&(e=e.filter(s=>this.kindFilter==="folder"?s.isDirectory:s.kind===this.kindFilter));let t=this.query.trim().toLowerCase();t&&(e=e.filter(s=>s.name.toLowerCase().includes(t)||(s.url||"").toLowerCase().includes(t))),this.visible=De(e,this.settings.get("sort_field","name"),this.settings.get("sort_direction","asc"),{foldersFirst:this.settings.get("sort_foldersFirst")!==!1})}onSearchInput(){this.query=this.searchInput.value||"",this.searchTimer&&window.clearTimeout(this.searchTimer),this.searchTimer=window.setTimeout(()=>{this.applyFilterAndSort(),this.renderBody()},140)}statusLine(){let e=[`${v(this.entries.length)} item${this.entries.length===1?"":"s"}`];return this.visible.length!==this.entries.length&&e.push(`${v(this.visible.length)} shown`),this.selecting&&e.push(`${v(this.selection.size)} selected`),this.settings.get("folder_recursive")===!0&&e.push("recursive"),e.join(" \xB7 ")}applySettings(){this.element.classList.toggle("fs-compact",this.settings.get("display_compactRows")===!0),this.element.classList.toggle("fs-hide-size",this.settings.get("display_showSize")===!1),this.element.classList.toggle("fs-hide-kind",this.settings.get("display_showKind")===!1),this.element.classList.toggle("fs-hide-icons",this.settings.get("display_showIcons")===!1),this.element.classList.toggle("fs-hide-modified",this.settings.get("display_showModified")===!1)}renderChips(){let e=Te(this.entries),t=[{kind:"all",label:"All",count:this.entries.length}];for(let{kind:s,count:i}of e)s==="other"&&i===0||t.push({kind:s,label:s==="folder"?"Folders":C(s),count:i});M(this.chips);for(let s of t)this.chips.appendChild(a("button",{class:"fs-chip",type:"button",text:`${s.label} ${v(s.count)}`,aria:{pressed:String(this.kindFilter===s.kind)},on:{click:()=>{this.kindFilter=s.kind,this.applyFilterAndSort(),this.renderChips(),this.renderBody()}}}))}renderBody(){M(this.body),this.view==="report"?this.body.appendChild(this.buildReportView()):this.view==="detail"?this.body.appendChild(this.buildDetail()):this.view==="preview"?this.body.appendChild(this.buildPreview()):this.body.appendChild(this.buildList()),this.footerText.textContent=this.statusLine(),this.batchBar.hidden=!this.selecting}buildList(){if(this.loading&&!this.entries.length)return a("div",{class:"fs-empty",text:"Scanning folder\u2026"});if(!this.rootUrl)return a("div",{class:"fs-empty"},[a("p",{text:"No folder selected."}),a("button",{class:"fs-btn",type:"button",text:"Choose folder",on:{click:()=>this.chooseFolder().then(()=>this.refresh())}})]);let e=this.visible.slice(0,ut),t=document.createDocumentFragment();if(t.appendChild(a("div",{class:"fs-summary"},this.buildSummaryBits())),!e.length)return t.appendChild(a("div",{class:"fs-empty",text:"Nothing matches this filter."})),t;let s=a("div",{class:"fs-list",role:"list"});for(let i of e)s.appendChild(this.buildRow(i));return t.appendChild(s),this.visible.length>e.length&&t.appendChild(a("div",{class:"fs-empty",text:`Showing the first ${v(e.length)} of ${v(this.visible.length)}. Narrow the filter to see the rest.`})),t}buildSummaryBits(){let e=this.entries.filter(i=>i.isFile),t=e.reduce((i,r)=>i+(r.size||0),0),s=e.reduce((i,r)=>Math.max(i,r.modified||0),0);return[a("span",{text:`${v(e.length)} files`}),a("span",{text:g(t)}),s?a("span",{text:`newest ${this.settings.get("display_relativeDate")!==!1?fe(s):E(s)}`}):null].filter(Boolean)}buildRow(e){let t=this.selection.has(e.url),s=this.settings.get("display_relativeDate")!==!1,i=[];e.isDirectory?i.push("Folder"):this.settings.get("display_showKind")!==!1&&i.push(C(e.kind)),this.settings.get("display_showModified")!==!1&&e.modified&&i.push(s?fe(e.modified):E(e.modified));let r=a("div",{class:`fs-row${t?" fs-selected":""}`,role:"listitem",tabindex:"0",dataset:{kind:e.kind||"file",url:e.url},aria:{selected:String(t)}},[k(gt[e.kind]||"file"),a("div",{class:"fs-main"},[a("span",{class:"fs-name",text:e.name}),a("span",{class:"fs-meta",text:i.join(" \xB7 ")})]),a("span",{class:"fs-size",text:e.isDirectory?"":g(e.size)}),a("button",{class:"fs-btn",type:"button",title:`Actions for ${e.name}`,aria:{label:`Actions for ${e.name}`},on:{click:c=>{c.stopPropagation(),this.showEntryMenu(e,c)}}},[k("more")])]),o=()=>{this.selecting?this.toggleSelected(e):this.activateEntry(e)};return r.addEventListener("click",o),r.addEventListener("keydown",c=>{(c.key==="Enter"||c.key===" ")&&(c.preventDefault(),o())}),r}async activateEntry(e){if(e.isDirectory){this.rootUrl=e.url,this.rootTitle=e.name,this.selection.clear(),this.kindFilter="all",this.view="list",this.settings.set(S.lastFolder,this.rootUrl,{silent:!0}),this.settings.set(S.lastFolderTitle,this.rootTitle,{silent:!0}),await this.refresh();return}this.previewEntry=e,this.view="preview",this.previewData=null,this.renderBody(),this.previewData=await this.actions.previewEntry(e),this.view==="preview"&&this.previewEntry===e&&this.renderBody()}showDetail(){this.view=this.view==="detail"?"list":"detail",this.renderBody()}buildDetail(){var i;let e=this.actions.summarize(this.entries),t=this.settings.get("tools_cleanupEnabled")!==!1,s=[a("section",{class:"fs-section"},[a("div",{style:{display:"flex",gap:"6px",flexWrap:"wrap",marginBottom:"10px"}},[a("button",{class:"fs-btn",type:"button",title:"Export folder report",aria:{label:"Export folder report"},on:{click:()=>this.exportReport()}},[k("file"),a("span",{text:"Export report"})]),a("button",{class:"fs-btn",type:"button",title:"View report as a page",aria:{label:"View report as a page"},on:{click:()=>this.showReportPage()}},[k("eye"),a("span",{text:"View page"})])]),a("h3",{text:"Folder summary"}),a("dl",{class:"fs-kv"},[a("dt",{text:"Files"}),a("dd",{text:v(e.totalFiles)}),a("dt",{text:"Folders"}),a("dd",{text:v(e.totalFolders)}),a("dt",{text:"Total size"}),a("dd",{text:g(e.totalSize)}),a("dt",{text:"Duplicate names"}),a("dd",{text:e.hasDuplicates?"Yes":"No"})])]),a("section",{class:"fs-section"},[a("h3",{text:"Largest files"}),this.buildMiniList(e.largestFiles)])];if(t){let r=this.actions.cleanupCandidates(this.entries);s.push(a("section",{class:"fs-section"},[a("h3",{text:"Cleanup candidates"}),r.length?this.buildMiniList(r.slice(0,8)):a("p",{class:"fs-meta",text:"No temporary or backup files found."})]))}return(i=e.duplicateGroups)!=null&&i.length&&s.push(a("section",{class:"fs-section"},[a("h3",{text:"Duplicate names"}),...e.duplicateGroups.slice(0,5).map(r=>{var o;return a("p",{class:"fs-meta",text:`${(o=r[0])==null?void 0:o.name} \u2014 ${r.length} copies`})})])),a("div",{},s)}buildMiniList(e){return e!=null&&e.length?a("dl",{class:"fs-kv"},e.flatMap(t=>[a("dt",{text:t.name,title:t.url,style:{overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}),a("dd",{text:g(t.size)})])):a("p",{class:"fs-meta",text:"Nothing to show."})}buildPreview(){let e=this.previewEntry;if(!e)return a("div",{class:"fs-empty",text:"Nothing selected."});let t=[a("button",{class:"fs-btn",type:"button",text:"Open in editor",on:{click:()=>this.actions.open(e)}}),a("button",{class:"fs-btn",type:"button",text:"Copy path",on:{click:()=>this.actions.copyPath(e)}}),a("button",{class:"fs-btn",type:"button",text:"Back to list",on:{click:()=>{this.view="list",this.renderBody()}}})],s=a("div",{},[a("section",{class:"fs-section"},[a("h3",{text:e.name}),a("dl",{class:"fs-kv"},[a("dt",{text:"Size"}),a("dd",{text:g(e.size)}),a("dt",{text:"Modified"}),a("dd",{text:E(e.modified)}),a("dt",{text:"Type"}),a("dd",{text:C(e.kind)})]),a("div",{style:{display:"flex",gap:"6px",marginTop:"10px",flexWrap:"wrap"}},t)])]);return this.previewData?(this.previewData.type==="text"&&this.previewData.ok?s.appendChild(a("div",{class:"fs-preview",text:this.previewData.text||""})):this.previewData.type==="image"&&this.previewData.ok?s.appendChild(a("div",{class:"fs-preview"},[a("img",{src:this.previewData.url,alt:`Preview of ${e.name}`})])):s.appendChild(a("div",{class:"fs-empty",text:this.previewData.message||"No preview available for this file."})),s):(s.appendChild(a("div",{class:"fs-empty",text:"Loading preview\u2026"})),s)}showEntryMenu(e,t){if(e.isDirectory){this.showMenu(t,[["Open folder",()=>this.activateEntry(e)],["Folder summary",()=>this.showDetail()],["Rename",()=>this.promptRename(e)],["Delete",()=>this.actions.deleteEntry(e).then(()=>this.refresh())]]);return}let s=[["Quick preview",()=>this.activateEntry(e)],["Open in editor",()=>this.actions.open(e)],["Copy path",()=>this.actions.copyPath(e)],["Copy name",()=>this.actions.copyName(e)],["Rename",()=>this.promptRename(e)],["Move to folder",()=>this.actions.moveEntries([e]).then(()=>this.refresh())],["Copy to folder",()=>this.actions.copyEntries([e]).then(()=>this.refresh())],["Delete",()=>this.actions.deleteEntry(e).then(()=>this.refresh())]];this.showMenu(t,s)}showFolderMenu(e){let t=this.rootUrl;this.showMenu(e,[["Change folder",()=>this.chooseFolder().then(()=>this.refresh())],["New file",()=>t&&this.actions.createFile(t).then(()=>this.refresh())],["New folder",()=>t&&this.actions.createFolder(t).then(()=>this.refresh())],["Export folder report",()=>this.exportReport()],["View report page",()=>this.showReportPage()],["Folder summary",()=>this.showDetail()],["Refresh",()=>this.refresh()]])}async showMenu(e,t){let s=t.map(([l])=>l),i=await A("Actions",s);if(i){let l=t.find(([h])=>h===i);l&&l[1]();return}let r=x("contextmenu");if(!r||!e)return;let o=e;new r({left:o.clientX||0,top:o.clientY||0,items:t.map(([l])=>[l,l]),onselect:l=>{var u;let h=l.target||l,p=(h==null?void 0:h.textContent)||((u=h==null?void 0:h.dataset)==null?void 0:u.action),d=t.find(([b])=>b===p);d&&d[1]()}}).show()}async promptRename(e){let t=await z("Rename",e.name,"text");!t||t===e.name||(await this.actions.renameEntry(e,t),await this.refresh())}selectedEntries(){return this.entries.filter(e=>this.selection.has(e.url))}toggleSelecting(){this.selecting=!this.selecting,this.selecting||this.selection.clear(),this.selectBtn.setAttribute("aria-pressed",String(this.selecting)),this.renderBody()}toggleSelected(e){this.selection.has(e.url)?this.selection.delete(e.url):this.selection.add(e.url);let t=this.body.querySelector(`.fs-row[data-url="${wt(e.url)}"]`);t&&(t.classList.toggle("fs-selected",this.selection.has(e.url)),t.setAttribute("aria-selected",String(this.selection.has(e.url)))),this.footerText.textContent=this.statusLine()}clearSelection(){this.selection.clear(),this.renderBody()}async runBatchDelete(){await this.actions.deleteEntries(this.selectedEntries()),this.selection.clear(),await this.refresh()}async runBatchRename(){let e=this.selectedEntries();if(!e.length){f("Select files first");return}let t=await A("Batch rename",["Add prefix","Add suffix","Replace text","Number sequentially","Change extension"]);if(!t)return;let s=null;if(t==="Add prefix"){let i=await z("Prefix to add","");if(!i)return;s=r=>`${i}${r.name}`}else if(t==="Add suffix"){let i=await z("Suffix to add (before extension)","");if(!i)return;s=r=>{let o=r.name.lastIndexOf(".");return o>0?`${r.name.slice(0,o)}${i}${r.name.slice(o)}`:`${r.name}${i}`}}else if(t==="Replace text"){let i=await z("Text to find","");if(!i)return;let r=await z("Replace with","");s=o=>o.name.split(i).join(r||"")}else if(t==="Number sequentially"){let i=await z("Name prefix","file");if(i==null)return;let o=Number(await z("Start at","1","number"))||1;s=c=>{let l=c.name.lastIndexOf("."),h=l>0?c.name.slice(l):"";return`${i}_${String(o++).padStart(3,"0")}${h}`}}else if(t==="Change extension"){let i=await z("New extension","txt");if(!i)return;let r=i.startsWith(".")?i:`.${i}`;s=o=>{let c=o.name.lastIndexOf(".");return c>0?`${o.name.slice(0,c)}${r}`:`${o.name}${r}`}}s&&(await this.actions.renameEntries(e,s),this.selection.clear(),await this.refresh())}async exportReport(){if(!this.rootUrl){f("Open a folder first");return}if(!this.entries.length){f("Nothing to report \u2014 the folder is empty");return}let e=this.rootTitle||L(this.rootUrl),t=this.settings.get("report_format","text"),s=ue(t),i=this.buildReportContent(t),r=oe(e,t),o=he(),c=["Open as page","Save in this folder"];o&&c.push("Save to app storage"),c.push("Share","Copy to clipboard");let l=await A("Export folder report",c);if(!l)return;if(l==="Open as page"){this.showReportPage();return}if(l==="Copy to clipboard"){let d=await this.actions.copyText(i);f(d?"Report copied to clipboard":"Could not copy the report");return}if(l==="Share"){if(await this.actions.shareText(i,r,s.mime))return;let u=await this.actions.copyText(i);f(u?"Sharing unavailable \u2014 report copied instead":"Could not share the report");return}let h=l==="Save to app storage"?o:this.rootUrl,p=await this.actions.saveTextFile(h,r,i);if(!p.ok){f(`Could not save report: ${p.message||"unknown error"}`);return}f(`Saved ${r}`),h===this.rootUrl&&await this.refresh()}buildReportContent(e="html"){return Le({rootTitle:this.rootTitle||L(this.rootUrl||"folder"),rootUrl:this.rootUrl||"",entries:this.entries,format:e,includePaths:this.settings.get("report_includePaths")===!0,includeListing:this.settings.get("report_includeListing")!==!1})}showReportPage(){if(!this.rootUrl){f("Open a folder first");return}if(!this.entries.length){f("Nothing to report \u2014 the folder is empty");return}this.reportContent=this.buildReportContent("html"),this.reportFileName=oe(this.rootTitle||L(this.rootUrl),"html"),this.view="report",this.renderBody()}buildReportView(){let e=a("iframe",{class:"fs-report-frame",sandbox:"",title:"Folder report"});e.setAttribute("srcdoc",this.reportContent||"");let t=a("div",{class:"fs-report-bar"},[a("button",{class:"fs-btn",type:"button",title:"Back to the list",aria:{label:"Back to the list"},on:{click:()=>{this.view="list",this.renderBody()}}},[k("back"),a("span",{text:"Back"})]),a("button",{class:"fs-btn",type:"button",title:"Open the report in a browser",aria:{label:"Open the report in a browser"},on:{click:()=>this.openReportInBrowser()}},[k("expand"),a("span",{text:"Browser"})]),a("button",{class:"fs-btn",type:"button",title:"Save the report",aria:{label:"Save the report"},on:{click:()=>this.exportReport()}},[k("file"),a("span",{text:"Save"})]),a("button",{class:"fs-btn",type:"button",title:"Copy the report source",aria:{label:"Copy the report source"},on:{click:async()=>{let s=await this.actions.copyText(this.reportContent);f(s?"Report source copied":"Could not copy the report")}}},[k("copy"),a("span",{text:"Copy"})])]);return a("div",{class:"fs-report"},[t,e])}async openReportInBrowser(){let e=this.reportContent||this.buildReportContent("html"),t=this.reportFileName||oe(this.rootTitle||L(this.rootUrl||"folder"),"html"),s=he()||this.rootUrl;if(!s){f("No writable location for the report");return}let i=await this.actions.saveTextFile(s,t,e);if(!i.ok||!i.url){f(`Could not write the report: ${i.message||"unknown error"}`);return}let r=await this.actions.displayUrl(i.url);r&&ze(r)||f(`Report saved as ${t}`)}async pickSort(){let e=this.settings.get("sort_field","name"),t=await A("Sort by",[{value:"name",text:"Name"},{value:"size",text:"Size"},{value:"date",text:"Date modified"},{value:"type",text:"Type"},{value:"toggle",text:"Reverse current order"}]);t&&(t==="toggle"?this.settings.set("sort_direction",this.settings.get("sort_direction")==="asc"?"desc":"asc"):t===e?this.settings.set("sort_direction",this.settings.get("sort_direction")==="asc"?"desc":"asc"):(this.settings.set("sort_field",t),this.settings.set("sort_direction","asc")),this.applyFilterAndSort(),this.renderBody())}};function V(n){let e=typeof window<"u"?window.innerWidth:1024,t=Math.max(Ae,Math.min(mt,Math.round(e*.92)));return Math.max(Ae,Math.min(t,Math.round(Number(n)||420)))}function L(n){let e=String(n||"").split("/").filter(Boolean);return e[e.length-1]||n}function wt(n){return typeof CSS<"u"&&typeof CSS.escape=="function"?CSS.escape(n):String(n).replace(/["\\]/g,"\\$&")}function ge(){if(document.getElementById(me))return;let n=document.createElement("style");n.id=me,n.textContent=Ie,document.head.appendChild(n)}var we="acode-fs-util-panel";function Oe(n){let{panel:e}=n;return function(i){ge(),M(i);let r=e.currentRoot(),o=a("div",{class:"fs-list",role:"list"}),c=a("div",{class:"fs-section"},[a("h3",{text:"Folder workspace"}),a("p",{class:"fs-meta",text:r||"No folder selected yet.",title:r||"",style:{wordBreak:"break-all"}})]),l=a("div",{style:{display:"flex",gap:"6px",flexWrap:"wrap"}},[a("button",{class:"fs-btn",type:"button",title:"Open folder workspace",aria:{label:"Open folder workspace"},on:{click:async()=>{await e.show()}}},[k("folder"),a("span",{text:"Open workspace"})]),a("button",{class:"fs-btn",type:"button",title:"Choose a folder",aria:{label:"Choose a folder"},on:{click:async()=>{let p=await _();p&&(await e.openRoot(p.url,p.title),await e.show())}}},[k("plus"),a("span",{text:"Folder"})]),r?a("button",{class:"fs-btn",type:"button",title:"Refresh folder",aria:{label:"Refresh folder"},on:{click:()=>e.refresh()}},[k("refresh")]):null].filter(Boolean));c.appendChild(a("div",{style:{marginTop:"8px"}},[l])),i.appendChild(c);let h=a("div",{class:"fs-section"},[a("h3",{text:"Open workspaces"}),o]);i.appendChild(h),t(o)};async function t(s){M(s),s.appendChild(a("p",{class:"fs-meta",text:"Loading workspaces\u2026"}));let i=[];try{i=await Se()}catch{i=[]}if(M(s),!i.length){s.appendChild(a("p",{class:"fs-meta",text:'No workspace folders are open. Use "Folder" above to pick one.'}));return}for(let r of i)s.appendChild(a("div",{class:"fs-row",role:"listitem",tabindex:"0",title:r.url,on:{click:async()=>{await e.openRoot(r.url,r.title),await e.show()},keydown:async o=>{let c=o.key;c!=="Enter"&&c!==" "||(o.preventDefault(),await e.openRoot(r.url,r.title),await e.show())}}},[k("folder"),a("div",{class:"fs-main"},[a("span",{class:"fs-name",text:r.title}),a("span",{class:"fs-meta",text:r.url})]),a("span",{class:"fs-size",text:""}),a("span",{class:"fs-size",text:""})]))}}var Pe=[{name:"fs.openWorkspace",description:"FS: Open the folder workspace"},{name:"fs.chooseFolder",description:"FS: Choose a folder to inspect"},{name:"fs.refresh",description:"FS: Refresh the open folder"},{name:"fs.summary",description:"FS: Show the folder summary"}],ye=class{constructor(e){this.settings=e,this.baseUrl="",this.panel=null,this.sideButton=null,this.disposers=[],this.initialised=!1}async init(e,t){if(this.initialised)return;if(!be()||!le()){f("FS needs a newer Acode version with the file system API");return}let s;try{s=new U}catch(d){console.warn("[FS] File system unavailable",d),f("FS could not reach the file system");return}let i=Ee(s),r=yt(s),o=new q(i),c=new J(o,this.scannerOptions()),l=new ee(new Z(i)),h=new te(r),p=new se({fileOps:r,access:o,batch:h,preview:l,settings:this.settings});this.panel=new ne({settings:this.settings,access:o,scanner:c,actions:p,preview:l}),this.panel.mount(document.body),this.disposers.push(this.settings.subscribe(()=>{c.setIgnoreList(this.settings.ignorePatterns()),c.setMaxFiles(Number(this.settings.get("folder_maxFiles"))||5e3),c.setMaxDepth(Number(this.settings.get("folder_maxDepth"))||3)})),this.registerSidebar(),this.registerSideButton(),this.registerCommands(),this.initialised=!0,console.log(`[FS] ready (v${R.version})`)}destroy(){var t,s,i,r,o,c;for(let l of this.disposers)try{l()}catch{}this.disposers=[];try{(s=(t=x("sidebarapps"))==null?void 0:t.remove)==null||s.call(t,we)}catch{}try{(r=(i=this.sideButton)==null?void 0:i.hide)==null||r.call(i)}catch{}let e=x("commands");for(let l of Pe)try{(o=e==null?void 0:e.removeCommand)==null||o.call(e,l.name)}catch{}(c=this.panel)==null||c.destroy(),this.panel=null,this.sideButton=null,this.initialised=!1}scannerOptions(){return{ignoreList:this.settings.ignorePatterns(),maxFiles:Number(this.settings.get("folder_maxFiles"))||5e3,maxDepth:Number(this.settings.get("folder_maxDepth"))||3}}registerSidebar(){let e=x("sidebarapps");if(!(!(e!=null&&e.add)||!this.panel))try{let t=Oe({panel:this.panel});e.add("folder",we,"FS Folder Workspace",t,!1,t)}catch(t){console.warn("[FS] Could not register sidebar app",t)}}registerSideButton(){var t,s;let e=x("sidebutton");if(!(!e||!this.panel))try{this.sideButton=e({text:"FS",onclick:()=>{var i;return(i=this.panel)==null?void 0:i.toggle()}}),(s=(t=this.sideButton)==null?void 0:t.show)==null||s.call(t)}catch(i){console.warn("[FS] Could not register side button",i)}}registerCommands(){let e=x("commands");if(!(e!=null&&e.addCommand))return;let t={"fs.openWorkspace":async()=>{var s;return await((s=this.panel)==null?void 0:s.show()),!0},"fs.chooseFolder":async()=>{let s=await _();return!s||!this.panel?!1:(await this.panel.openRoot(s.url,s.title),await this.panel.show(),!0)},"fs.refresh":async()=>{var s;return await((s=this.panel)==null?void 0:s.refresh()),!0},"fs.summary":async()=>this.panel?(await this.panel.show(),this.panel.showDetail(),!0):!1};for(let s of Pe)try{e.addCommand({name:s.name,description:s.description,exec:t[s.name]})}catch(i){console.warn(`[FS] Could not register ${s.name}`,i)}}};function yt(n){let e=t=>typeof t=="string"?t:t==null?void 0:t.url;return{open:t=>n.openInEditor(t),remove:t=>n.remove(e(t)),rename:(t,s)=>n.rename(e(t),s),move:(t,s)=>n.move(e(t),s),copy:(t,s)=>n.copy(e(t),s),createFile:(t,s,i)=>n.createFile(t,s,i),createDirectory:(t,s)=>n.createDirectory(t,s),displayUrl:t=>n.displayUrl(t)}}if(window.acode){let n=new W({pluginId:R.id}),e=new ye(n);acode.setPluginInit(R.id,async(t,s,i)=>{e.baseUrl=t.endsWith("/")?t:`${t}/`,await e.init(s,i)},{list:n.toHostSettings(),cb:(t,s)=>n.applyExternal(t,s)}),acode.setPluginUnmount(R.id,()=>{e.destroy()})}})();
